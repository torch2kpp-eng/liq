# PHASE_1.md — Structural Validation & Quantified Acceptance

> **담당 서브에이전트**: C  
> **기간**: W3~W4  
> **선행 조건**: Gate B 통과 (Phase 0 완료)  
> **Gate**: Gate C → Phase 2 진입 허용

---

## 🎯 이 Phase의 목적

> "성능 자랑이 아니라 구조 증명. 무엇이 어떤 조건에서만 유효한지 명확히 아는 것."

알파/레짐/게이트 구조가 OOS에서 실제로 수치적으로 분화되는지 판정.  
통과해야 할 것: **state-conditioned separation, conditional lift, drawdown 완화, artifact reproducibility**

---

## 📋 Workstream 구조

| WS | 주제 | 핵심 가설 |
|----|------|-----------|
| WS-A | Path vs Position Multiplier | Position은 방향 무관 손실 완화, Path는 base 방향 적중 시만 유효 |
| WS-B | Horizon-specific Alpha Ablation | Funding은 단기, MVRV/Reserve는 중장기, Halving은 interaction gate |
| WS-C | ETF Lead-Lag & Gating | ETF는 선행성 미검증 전 confirmation signal 유지 |
| WS-D | State Separation & Acceptance | 정량 기준으로 Phase 2 진입 여부 판정 |

---

## WS-A: Path Multiplier vs Position Multiplier

### 핵심 코드

```python
# src/strategy/path_calibration.py

class PathMultiplier:
    """
    Base forecast의 경로(크기)를 alpha state에 따라 보정.
    
    중요 원칙:
    - path multiplier는 부호(방향)를 바꾸지 않는다
    - base 방향이 맞을 때만 의미 있는 효과 발생
    - multiplier 범위: [0.65, 1.35]로 clip
    """
    
    MULTIPLIER_CLIP = (0.65, 1.35)
    
    def compute_multiplier(
        self,
        base_forecast: float,
        alpha_score_norm: float,
        impact: float = 1.0
    ) -> float:
        """
        Base forecast 부호와 alpha 부호가 같으면 > 1.0
        반대이면 < 1.0
        """
        base_sign = 1 if base_forecast > 0 else -1
        alpha_sign = 1 if alpha_score_norm > 0 else -1
        
        if base_sign == alpha_sign:
            # 같은 방향: 강화
            raw_multiplier = 1.0 + abs(alpha_score_norm) * impact
        else:
            # 다른 방향: 감쇠
            raw_multiplier = 1.0 - abs(alpha_score_norm) * impact
        
        return float(np.clip(raw_multiplier, *self.MULTIPLIER_CLIP))
    
    def apply(self, base_forecast: float, multiplier: float) -> float:
        """부호는 절대 바꾸지 않음"""
        adjusted = base_forecast * multiplier
        # 부호 보존 확인
        assert np.sign(adjusted) == np.sign(base_forecast), \
            "Path multiplier가 부호를 바꿨습니다 — 버그!"
        return adjusted


# src/strategy/position_sizing.py

class PositionMultiplier:
    """
    Alpha state에 따른 포지션 크기 조정.
    방향이 틀린 예측에서도 손실 크기를 제한하는 것이 핵심 목적.
    """
    
    STATE_MULTIPLIERS = {
        "STRONG_BEAR": 0.25,
        "BEARISH": 0.55,
        "NEUTRAL": 0.85,
        "BULLISH": 1.00,
        "STRONG_BULL": 1.10
    }
    
    def compute_position_size(
        self,
        base_position: float,
        alpha_state: str,
        impact: float = 1.0
    ) -> float:
        """
        base_position과 state multiplier를 impact 비율로 블렌딩.
        impact=0이면 base_position 그대로, impact=1이면 완전 state 기반.
        """
        state_mult = self.STATE_MULTIPLIERS.get(alpha_state, 1.0)
        
        blended = base_position * (
            (1 - impact) + impact * state_mult
        )
        return blended
```

### 실험 설계

```python
# 실험 ID: A1~A4

EXPERIMENTS_WS_A = [
    {
        "id": "A1",
        "name": "Base forecast only",
        "description": "기준선. path/position multiplier 없음",
        "config": {
            "use_path_multiplier": False,
            "use_position_multiplier": False
        }
    },
    {
        "id": "A2", 
        "name": "Base + Position multiplier",
        "description": "risk reduction 우선 확인",
        "config": {
            "use_path_multiplier": False,
            "use_position_multiplier": True
        }
    },
    {
        "id": "A3",
        "name": "Base + Path multiplier",
        "description": "conditional lift 확인 (base 방향 분리 필수)",
        "config": {
            "use_path_multiplier": True,
            "use_position_multiplier": False
        }
    },
    {
        "id": "A4",
        "name": "Base + Position + Path",
        "description": "결합 시 추가 가치 확인",
        "config": {
            "use_path_multiplier": True,
            "use_position_multiplier": True
        }
    }
]


def evaluate_path_multiplier_conditional(
    predictions_df: pd.DataFrame
) -> dict:
    """
    Path multiplier를 반드시 base 방향 적중/오적중 샘플 분리하여 평가.
    전체 평균만으로 폐기 금지.
    """
    
    # 샘플 분류
    base_correct = predictions_df[
        np.sign(predictions_df["base_forecast"]) == 
        np.sign(predictions_df["y_true"])
    ]
    base_wrong = predictions_df[
        np.sign(predictions_df["base_forecast"]) != 
        np.sign(predictions_df["y_true"])
    ]
    
    # 평가
    result = {}
    
    for label, subset in [
        ("all", predictions_df),
        ("base_correct", base_correct),
        ("base_wrong", base_wrong)
    ]:
        result[label] = {
            "n_samples": len(subset),
            "mae_base": mean_absolute_error(subset["y_true"], subset["base_forecast"]),
            "mae_path_adjusted": mean_absolute_error(
                subset["y_true"], subset["path_adjusted_forecast"]
            ),
            "mae_improvement": (
                mean_absolute_error(subset["y_true"], subset["base_forecast"]) -
                mean_absolute_error(subset["y_true"], subset["path_adjusted_forecast"])
            ),
            "max_dd_base": compute_max_drawdown(subset["base_forecast"]),
            "max_dd_adjusted": compute_max_drawdown(subset["path_adjusted_forecast"])
        }
    
    # 해석 규칙: base_correct에서 conditional lift 있으면 조건부 채택 가능
    result["recommendation"] = (
        "conditional_adopt" 
        if result["base_correct"]["mae_improvement"] > 0 
        else "reject"
    )
    
    return result
```

### 판정 기준

| 실험 | 주요 지표 | 통과 기준 |
|------|-----------|-----------|
| A2 (Position) | Max DD, downside deviation | base 대비 DD 개선 |
| A3 (Path) | base 방향 적중 샘플에서만 lift | conditional lift > 0 |
| A4 (Combined) | A2 + A3 기준 동시 충족 | 과잉 변동 없이 개선 |

---

## WS-B: Horizon-specific Alpha Ablation

```python
# 실험 ID: B1~B6

EXPERIMENTS_WS_B = [
    {"id": "B1", "name": "All-alpha baseline",
     "weights": {"mvrv": 1.0, "reserve": 1.0, "etf": 1.0, 
                 "funding": 1.0, "halving": 1.0}},
    
    {"id": "B2", "name": "No Funding",
     "description": "13w/26w에서 개선 여부 확인",
     "weights": {"mvrv": 1.0, "reserve": 1.0, "etf": 1.0, 
                 "funding": 0.0, "halving": 1.0}},
    
    {"id": "B3", "name": "No Halving",
     "description": "4w/8w noise 감소 확인",
     "weights": {"mvrv": 1.0, "reserve": 1.0, "etf": 1.0,
                 "funding": 1.0, "halving": 0.0}},
    
    {"id": "B4", "name": "No ETF",
     "description": "ETF 과최적화 여부 확인",
     "weights": {"mvrv": 1.0, "reserve": 1.0, "etf": 0.0,
                 "funding": 1.0, "halving": 1.0}},
    
    {"id": "B5", "name": "Short-horizon pack (4w/8w)",
     "description": "단기 전용: Funding↑, Halving 최소화",
     "weights": {"mvrv": 0.5, "reserve": 1.0, "etf": 1.0,
                 "funding": 1.5, "halving": 0.0},
     "target_horizons": [4, 8]},
    
    {"id": "B6", "name": "Long-horizon pack (13w/26w)",
     "description": "장기 전용: MVRV/Reserve↑, Funding 제외",
     "weights": {"mvrv": 1.5, "reserve": 1.5, "etf": 1.0,
                 "funding": 0.0, "halving": 0.8},
     "target_horizons": [13, 26]}
]


def run_ablation_experiment(
    experiment_config: dict,
    panel: pd.DataFrame,
    horizons: list[int] = None
) -> pd.DataFrame:
    """
    Ablation 실험 실행.
    각 horizon별로 IC, rank_IC, sign_accuracy 계산.
    """
    target_horizons = experiment_config.get("target_horizons", [4, 8, 13, 26])
    weights = experiment_config["weights"]
    
    results = []
    
    for horizon in target_horizons:
        # 가중치 적용한 custom alpha score 계산
        panel_copy = panel.copy()
        panel_copy = apply_custom_weights(panel_copy, weights)
        
        # Walk-forward OOS
        oos_preds = walk_forward_oos(panel_copy, horizon=horizon)
        
        # 조건부 메트릭
        slice_metrics = compute_slice_metrics(oos_preds, horizon=horizon)
        slice_metrics["experiment_id"] = experiment_config["id"]
        
        results.append(slice_metrics)
    
    return pd.concat(results)


def compare_ablation_results(
    baseline: pd.DataFrame,  # B1 결과
    variant: pd.DataFrame    # B2~B6 결과
) -> dict:
    """
    baseline 대비 variant의 IC 변화 분석.
    어떤 신호가 어떤 horizon에서 기여/노이즈인지 분해.
    """
    comparison = {}
    
    for horizon in [4, 8, 13, 26]:
        b_ic = baseline[baseline["horizon"] == horizon]["ic"].mean()
        v_ic = variant[variant["horizon"] == horizon]["ic"].mean()
        
        comparison[horizon] = {
            "baseline_ic": b_ic,
            "variant_ic": v_ic,
            "delta_ic": v_ic - b_ic,
            "improved": v_ic > b_ic,
            "passes_degradation_check": (v_ic - b_ic) > -0.01  # 비타깃 horizon 악화 한도
        }
    
    return comparison
```

### 산출물: Horizon-specific Alpha Map

```
Phase 1 완료 후 확정해야 할 alpha map 형태:

Short-horizon pack (4w, 8w):
  - mvrv_weight: TBD (실험으로 결정)
  - funding_weight: TBD
  - etf_weight: TBD
  - halving_weight: 0.0 (B3에서 검증)

Long-horizon pack (13w, 26w):
  - mvrv_weight: TBD
  - reserve_weight: TBD
  - funding_weight: TBD or 0.0 (B2에서 검증)
  - halving_weight: TBD
```

---

## WS-C: ETF Lead-Lag & Gating

```python
# src/alpha/lead_lag.py

def run_lead_lag_analysis(
    etf_flow: pd.Series,
    btc_returns: pd.Series,
    max_lag_weeks: int = 8
) -> pd.DataFrame:
    """
    ETF flow(t-k)와 BTC return(t) 사이의 상관관계를 k별로 측정.
    
    k > 0에서 유의미한 상관 → 진정한 선행 지표
    k = 0에서만 상관 → 동행 변수 (look-ahead bias 위험)
    
    Returns:
        DataFrame with columns: [lag_weeks, correlation, t_stat, p_value, interpretation]
    """
    results = []
    
    for k in range(0, max_lag_weeks + 1):
        if k == 0:
            etf_lagged = etf_flow
        else:
            etf_lagged = etf_flow.shift(k)
        
        # 유효한 데이터만 사용
        valid_mask = ~(etf_lagged.isna() | btc_returns.isna())
        
        corr, p_value = pearsonr(
            etf_lagged[valid_mask], 
            btc_returns[valid_mask]
        )
        
        n = valid_mask.sum()
        t_stat = corr * np.sqrt(n - 2) / np.sqrt(1 - corr**2)
        
        results.append({
            "lag_weeks": k,
            "correlation": corr,
            "t_stat": t_stat,
            "p_value": p_value,
            "n_samples": n,
            "interpretation": (
                "선행 지표 후보" if k > 0 and abs(t_stat) > 1.5
                else "동행 변수 (look-ahead 위험)" if k == 0 and abs(t_stat) > 1.5
                else "유의미하지 않음"
            )
        })
    
    return pd.DataFrame(results)


def determine_etf_feature_status(lead_lag_results: pd.DataFrame) -> str:
    """
    Lead-lag 분석 결과에 따른 ETF 처리 방식 결정.
    
    Returns:
        "predictive_feature": k>0에서 유의미 → 예측 feature로 승격
        "confirmation_signal": k=0에서만 유의미 → confirmation으로 유지
        "no_information": 전체 무의미 → 제거
    """
    lag_positive = lead_lag_results[lead_lag_results["lag_weeks"] > 0]
    lag_zero = lead_lag_results[lead_lag_results["lag_weeks"] == 0]
    
    has_leading = (lag_positive["t_stat"].abs() > 1.5).any()
    has_contemporaneous = (lag_zero["t_stat"].abs() > 1.5).any()
    
    if has_leading:
        return "predictive_feature"
    elif has_contemporaneous:
        return "confirmation_signal"  # look-ahead 위험 → 예측 feature 금지
    else:
        return "no_information"


class ETFStreakGate:
    """
    ETF flow 전환 구간 처리.
    연속 방향 유지 주수(streak)가 충분해야 alpha에 반영.
    """
    
    MIN_STREAK_BULLISH = 3   # 3주 이상 유입 → BULLISH 방향 반영
    MIN_STREAK_BEARISH = 3   # 3주 이상 유출 → BEARISH 방향 반영
    
    def get_gated_signal(
        self,
        etf_weekly_flow: pd.Series  # 양수=유입, 음수=유출
    ) -> pd.Series:
        """
        Streak이 짧으면 neutral, 충분하면 방향 반영.
        whipsaw 완화 목적.
        """
        streak = compute_directional_streak(etf_weekly_flow)
        
        gated = pd.Series(index=etf_weekly_flow.index, dtype=float)
        
        for i, (date, flow) in enumerate(etf_weekly_flow.items()):
            current_streak = streak.iloc[i]
            
            if flow > 0 and current_streak >= self.MIN_STREAK_BULLISH:
                gated[date] = 1.0   # BULLISH
            elif flow < 0 and abs(current_streak) >= self.MIN_STREAK_BEARISH:
                gated[date] = -1.0  # BEARISH
            else:
                gated[date] = 0.0   # NEUTRAL (전환 구간)
        
        return gated
```

### ETF 실험 설계

| 실험 ID | 내용 | 의사결정 규칙 |
|---------|------|---------------|
| C1 | Lead-lag screen (k=1/2/4/8주) | k>0 유의미 없으면 예측 feature 승격 금지 |
| C2 | Availability audit | PIT rule 위반 여부 점검 |
| C3 | Partial weight OOS (0.5× vs 1.0× vs 제외) | 보수적 투입이 더 안정적인지 확인 |
| C4 | Streak gating (1주 reversal=neutral, 3주+만 반영) | whipsaw 완화 여부 |
| C5 | Pre/Post split report | 전체 평균 왜곡 방지 |

---

## WS-D: State Separation & 2D Matrix

```python
# src/validation/conditional_metrics.py

def compute_state_conditioned_metrics(
    predictions_df: pd.DataFrame,
    horizons: list[int] = [4, 8, 13, 26],
    alpha_states: list[str] = ["STRONG_BEAR", "BEARISH", "NEUTRAL", 
                                "BULLISH", "STRONG_BULL"],
    macro_regimes: list[str] = ["stress", "equilibrium", "trend"]
) -> pd.DataFrame:
    """
    State별 OOS 조건부 메트릭 계산.
    반드시 sample count와 함께 출력 (sample 수 없는 평균 금지).
    """
    results = []
    
    for horizon in horizons:
        h_data = predictions_df[predictions_df["horizon"] == horizon]
        
        for alpha_state in alpha_states:
            for macro_regime in macro_regimes:
                
                subset = h_data[
                    (h_data["alpha_state"] == alpha_state) &
                    (h_data["macro_regime"] == macro_regime)
                ]
                
                n_samples = len(subset)
                
                if n_samples < ACCEPTANCE_CRITERIA["min_samples_hard_floor"]:
                    # 10개 미만 → 평가 보류
                    row = {
                        "horizon": horizon,
                        "alpha_state": alpha_state,
                        "macro_regime": macro_regime,
                        "n_samples": n_samples,
                        "status": "INSUFFICIENT_SAMPLES",
                        "ic": np.nan,
                        "rank_ic": np.nan,
                        "sign_acc": np.nan,
                        "etf_available": subset["etf_available"].mean()
                    }
                else:
                    ic = compute_ic(subset["y_true"], subset["y_pred"])
                    rank_ic = compute_rank_ic(subset["y_true"], subset["y_pred"])
                    sign_acc = compute_sign_accuracy(subset["y_true"], subset["y_pred"])
                    
                    row = {
                        "horizon": horizon,
                        "alpha_state": alpha_state,
                        "macro_regime": macro_regime,
                        "n_samples": n_samples,
                        "status": "EVALUATED",
                        "ic": ic,
                        "rank_ic": rank_ic,
                        "sign_acc": sign_acc,
                        "mean_fwd_return": subset["y_true"].mean(),
                        "etf_available": subset["etf_available"].mean()
                    }
                
                results.append(row)
    
    return pd.DataFrame(results)


def compute_2d_regime_alpha_matrix(
    slice_metrics: pd.DataFrame,
    horizon: int
) -> pd.DataFrame:
    """
    macro_regime × alpha_state 2D 매트릭스 생성.
    Phase 1의 핵심 결과물.
    """
    h_data = slice_metrics[slice_metrics["horizon"] == horizon]
    
    matrix = h_data.pivot_table(
        values=["ic", "n_samples", "sign_acc"],
        index="macro_regime",
        columns="alpha_state",
        aggfunc="mean"
    )
    
    return matrix
```

---

## Phase 1 종료: 최종 의사결정 (D1~D5)

```python
# 반드시 답해야 하는 5개 질문

PHASE1_DECISIONS = {
    "D1": {
        "question": "Position multiplier를 production-calibration 후보로 승격할 것인가?",
        "criteria": "DD/downside 개선 여부와 안정성",
        "options": ["PROMOTE", "HOLD", "REJECT"]
    },
    "D2": {
        "question": "Path multiplier를 조건부 기능으로 유지할 것인가?",
        "criteria": "base 방향 적중 샘플에서 conditional lift 재현 여부",
        "options": ["CONDITIONAL_ADOPT", "HOLD_FOR_MORE_DATA", "REJECT"]
    },
    "D3": {
        "question": "Short-horizon / Long-horizon alpha pack 분리 채택?",
        "criteria": "horizon별 승자 조합 존재 여부",
        "options": ["SPLIT", "UNIFIED", "NEEDS_MORE_EXPERIMENTS"]
    },
    "D4": {
        "question": "ETF를 예측 feature로 승격 vs confirmation/meta 유지?",
        "criteria": "lead-lag 선행성 검증 결과",
        "options": ["PROMOTE_PREDICTIVE", "MAINTAIN_CONFIRMATION", "REMOVE"]
    },
    "D5": {
        "question": "Phase 2에서 어떤 신호를 확장하고 어떤 신호를 보류?",
        "criteria": "ablation 결과 기반 무효 signal 제거 여부",
        "options": ["Phase 2 진입 신호팩 목록 명시"]
    }
}
```

## ✅ Gate C 통과 조건

```
□ WS-A: Position multiplier — DD 개선 확인, Path multiplier — conditional lift 분리 확인
□ WS-B: Horizon별 ablation 완료, short/long alpha pack 초안 확정
□ WS-C: ETF lead-lag 분석 완료, 처리 방식 결정 (predictive/confirmation/remove)
□ WS-D: State separation 정량 기준 충족 여부 확인
□ 5개 Phase 1 Decision (D1~D5) 모두 판정 완료
□ phase_decision_card.md 작성 완료

Gate C 실패 조건:
- D1~D5 중 판정 미완료 항목 존재
- "좋아 보이는 그림"만 있고 정량 기준 판정 없음
- base 방향 분리 없이 path multiplier 평가
```
