# PHASE_3.md — Interaction-first ML Evolution

> **담당 서브에이전트**: E  
> **기간**: W9~W12  
> **선행 조건**: G2-In 통과 (승격 신호팩 확정)  
> **Gate**: G3-In (conditional lift + calibration 개선 확인)

---

## 🎯 목적

> "더 복잡한 모델이 아니라, interaction-first 구조를 정식 모델 계층에 주입하는 것."

순서: ECM/Ridge interaction → LightGBM → Stacking → Calibration → HMM  
(Sequence model은 이 단계에서 절대 투입 금지)

---

## WS-3A: ECM/Ridge Interaction Block

```python
# src/models/interaction_block.py

class AlphaInteractionBlock:
    """
    ECM/Ridge에 alpha_state × macro_regime × horizon 조건부 정보 주입.
    가장 해석 가능한 방식으로 먼저 uplift를 찾는다.
    """
    
    def create_interaction_features(
        self,
        df: pd.DataFrame,
        horizon: int
    ) -> pd.DataFrame:
        """
        Interaction features 생성.
        score 정의 변경과 threshold 재튜닝을 동시에 하지 않는다.
        """
        result = df.copy()
        
        # Alpha state one-hot
        state_dummies = pd.get_dummies(df["alpha_state"], prefix="alpha_state")
        result = pd.concat([result, state_dummies], axis=1)
        
        # Macro × Alpha interaction
        for macro_col in ["liquidity_z", "dxy_z", "risk_state"]:
            if macro_col in df.columns:
                for state in ["BULLISH", "BEARISH"]:
                    state_col = f"alpha_state_{state}"
                    if state_col in result.columns:
                        result[f"{macro_col}_x_{state}"] = (
                            result[macro_col] * result[state_col]
                        )
        
        # Horizon-specific conditioning
        result[f"horizon_{horizon}_indicator"] = 1
        for state in ["BULLISH", "BEARISH", "STRONG_BULL", "STRONG_BEAR"]:
            state_col = f"alpha_state_{state}"
            if state_col in result.columns:
                result[f"h{horizon}_{state}_interaction"] = (
                    result[state_col] * horizon / 26.0  # 정규화
                )
        
        # ETF availability conditioning
        result["etf_x_alpha"] = result.get("etf_available", 0) * result.get("alpha_score_norm", 0)
        
        return result
    
    def run_ablation(
        self,
        df: pd.DataFrame,
        horizon: int,
        interaction_types: list[str] = ["alpha_state", "macro_x_alpha", "horizon_specific"]
    ) -> dict:
        """
        interaction on/off, horizon별 pack 차등 ablation.
        무슨 interaction이 실제로 기여하는지 분해.
        """
        results = {}
        
        # 기준선: interaction 없음
        results["baseline"] = train_and_eval(df, horizon, use_interactions=[])
        
        # 각 interaction 유형별 추가
        for interaction in interaction_types:
            results[interaction] = train_and_eval(
                df, horizon, use_interactions=[interaction]
            )
        
        # 전체 조합
        results["all_interactions"] = train_and_eval(
            df, horizon, use_interactions=interaction_types
        )
        
        return results


# 실험 P3-A1~A3
EXPERIMENTS_WS_3A = [
    {"id": "P3-A1", 
     "model": "ECM",
     "interactions": ["alpha_state", "macro_x_alpha", "coint_x_alpha", "horizon_pack"],
     "criterion": "base ECM 대비 slice lift"},
    
    {"id": "P3-A2",
     "model": "Ridge",
     "description": "규제 강한 선형 구조에서 interaction만 추가",
     "criterion": "과적합 없이 단기 lift"},
    
    {"id": "P3-A3",
     "name": "Interaction ablation",
     "description": "on/off 조합으로 실제 기여 interaction 분해",
     "criterion": "attribution 명확화"}
]
```

---

## WS-3B: LightGBM

```python
# src/models/lightgbm_model.py

class LightGBMCandidate:
    """
    XGBoost 대안 또는 Ensemble diversity 확보용.
    전체 평균보다 slice별 conditional lift 중심 평가.
    """
    
    BASE_PARAMS = {
        "objective": "regression",
        "num_leaves": 15,       # 얕은 depth
        "min_child_samples": 20, # 과적합 방지
        "learning_rate": 0.05,
        "n_estimators": 200,
        "early_stopping_rounds": 20,
        "verbose": -1
    }
    
    MONOTONIC_CONSTRAINTS_TEMPLATE = {
        # 핵심 macro feature에 방향성 제약 (선택적)
        # 1 = 단조 증가, -1 = 단조 감소, 0 = 제약 없음
        "liquidity_z": 1,       # 유동성 증가 → BTC 긍정
        "mvrv_z": -1,           # MVRV 과열 → BTC 부정
        # 나머지는 0으로 설정
    }
    
    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        use_monotonic: bool = False
    ) -> "LightGBMCandidate":
        params = self.BASE_PARAMS.copy()
        
        if use_monotonic:
            # 설명력 훼손 없이 과적합 완화 시도
            constraints = [
                self.MONOTONIC_CONSTRAINTS_TEMPLATE.get(col, 0) 
                for col in X_train.columns
            ]
            params["monotone_constraints"] = constraints
        
        self.model = lgb.train(
            params,
            lgb.Dataset(X_train, y_train),
            valid_sets=[lgb.Dataset(X_val, y_val)],
            callbacks=[lgb.early_stopping(20), lgb.log_evaluation(50)]
        )
        return self

# 승격 기준: 장기 horizon 붕괴 없이 ensemble diversity 제공
# 폐기 조건: 4w만 좋아지고 26w 붕괴 시 → 보류
```

---

## WS-3C: Stacking / Meta-ensemble

```python
# src/models/ensemble.py

class SegmentedStacking:
    """
    단순 평균 성능이 아니라 horizon/regime별 안정성(variance 감소) 목적.
    """
    
    def train_meta_learner(
        self,
        base_predictions: dict[str, pd.Series],  # {model_name: predictions}
        y_true: pd.Series,
        segment: str = "global"  # "global" | f"h{horizon}" | f"{regime}"
    ) -> "SegmentedStacking":
        """
        base models의 예측을 meta-learner로 결합.
        segment별로 다른 meta weight 허용.
        """
        X_meta = pd.DataFrame(base_predictions)
        
        # Ridge meta-learner (단순하고 해석 가능)
        self.meta_model = Ridge(alpha=1.0)
        self.meta_model.fit(X_meta, y_true)
        
        return self

# 판정 기준: 평균 MAE보다 variance/DD 안정화 중심
# 금지: 평균 수치만 좋다고 채택 금지
```

---

## WS-3D: Calibration & Uncertainty

```python
# src/models/calibration.py

class ResidualBandCalibrator:
    """
    예측 불확실성의 coverage calibration.
    Phase 4 position sizing 연결을 위한 필수 준비.
    """
    
    def fit(
        self,
        predictions: pd.Series,
        actuals: pd.Series,
        regime_labels: pd.Series | None = None
    ) -> "ResidualBandCalibrator":
        """
        conditional vs unconditional residual band 비교.
        regime-conditioned band가 coverage를 개선하는지 확인.
        """
        residuals = actuals - predictions
        
        if regime_labels is not None:
            # Regime별 별도 band
            self.regime_bands = {}
            for regime in regime_labels.unique():
                mask = regime_labels == regime
                self.regime_bands[regime] = {
                    "std": residuals[mask].std(),
                    "q05": residuals[mask].quantile(0.05),
                    "q95": residuals[mask].quantile(0.95)
                }
        else:
            # Unconditional band
            self.global_band = {
                "std": residuals.std(),
                "q05": residuals.quantile(0.05),
                "q95": residuals.quantile(0.95)
            }
        
        return self
    
    def compute_confidence_to_size_mapping(
        self,
        confidence_scores: pd.Series,
        subsequent_errors: pd.Series
    ) -> pd.DataFrame:
        """
        model confidence와 subsequent error의 상관 구조.
        Phase 4 position sizing 연결을 위한 사전 분석.
        """
        return pd.DataFrame({
            "confidence": confidence_scores,
            "abs_error": subsequent_errors.abs(),
            "confidence_quantile": pd.qcut(confidence_scores, q=5, labels=False)
        }).groupby("confidence_quantile").agg({
            "abs_error": ["mean", "std", "count"]
        })
```

---

## WS-3E: HMM Probability Layer

```python
# src/models/hmm_layer.py

class HMMStateLayer:
    """
    Rule-based regime를 확률적 상태 변수로 보강.
    rule regime의 유효성이 먼저 입증된 뒤에만 투입.
    설명 불가능한 state 분할이면 폐기.
    """
    
    def __init__(self, n_states: int = 3):
        assert 2 <= n_states <= 4, "HMM state 수는 2~4개로 제한"
        self.n_states = n_states
        self.model = GaussianHMM(n_components=n_states, covariance_type="full")
    
    def fit(self, X: np.ndarray) -> "HMMStateLayer":
        self.model.fit(X)
        self._label_states()
        return self
    
    def _label_states(self):
        """
        HMM state를 경제적으로 해석 가능한 레이블로 매핑.
        해석 불가능하면 이 단계에서 폐기.
        """
        means = self.model.means_
        # 평균 수익률 기준 정렬
        sorted_indices = np.argsort(means.flatten())
        self.state_labels = {
            sorted_indices[0]: "latent_bear",
            sorted_indices[-1]: "latent_bull",
            # 중간 state(s)
        }
    
    def get_state_probabilities(self, X: np.ndarray) -> pd.DataFrame:
        """각 시점별 state 확률 반환"""
        _, posteriors = self.model.score_samples(X)
        return pd.DataFrame(
            posteriors,
            columns=[f"hmm_prob_{self.state_labels.get(i, i)}" 
                    for i in range(self.n_states)]
        )
```

## ✅ G3-In 통과 조건
```
□ ECM/Ridge interaction: 최소 2개 horizon에서 conditional lift 재현
□ LightGBM: 장기 horizon 붕괴 없이 채택 여부 결정
□ Stacking: variance/DD 안정화 확인
□ Calibration: coverage error 감소 확인
□ HMM: rule regime 대비 incremental value 판정 (없으면 폐기)
□ champion 후보 config 확정
```
