# PHASE_4.md — Forecast → Position Translation

> **담당 서브에이전트**: F  
> **기간**: W13~W14  
> **선행 조건**: G4-In (조건부 lift 또는 calibration lift 재현)  
> **Gate**: G5-In

---

## 🎯 목적

> "예측 엔진을 전략 엔진으로 바꾸는 단계. 수익률 극대화가 아니라 risk-adjusted quality 개선."

핵심 원칙: forecast quality와 strategy quality는 다른 대상이다.  
- MAE가 나빠져도 DD가 크게 줄면 전략층에서 승격 가능  
- 예측력이 좋아도 turnover/비용 때문에 실전성 없으면 보류

---

## WS-4A: Signal-to-Position Mapping

```python
# src/strategy/signal_to_position.py

class PositionPolicyLibrary:
    """
    예측값 → 포지션 크기 번역 방식 비교.
    """
    
    def sign_only_policy(
        self,
        forecast: pd.Series,
        long_only: bool = True
    ) -> pd.Series:
        """
        P4-A1: 예측 방향만 사용. 가장 단순한 기준선.
        """
        if long_only:
            return (forecast > 0).astype(float)  # 1.0 or 0.0
        else:
            return np.sign(forecast).astype(float)  # 1.0, 0.0, -1.0
    
    def strength_bucket_policy(
        self,
        forecast: pd.Series,
        n_buckets: int = 5
    ) -> pd.Series:
        """
        P4-A2: 예측 절대값을 3~5 bucket으로 나눠 sizing.
        경로 크기 정보의 실전 유용성 확인.
        """
        abs_forecast = forecast.abs()
        buckets = pd.qcut(abs_forecast, q=n_buckets, labels=False, duplicates="drop")
        
        # bucket 번호를 0~1 사이로 정규화
        max_bucket = buckets.max()
        sizes = (buckets + 1) / (max_bucket + 1)
        
        # 방향 적용
        return sizes * np.sign(forecast)
    
    def confidence_weighted_policy(
        self,
        forecast: pd.Series,
        alpha_score_norm: pd.Series,
        coverage: pd.Series | None = None
    ) -> pd.Series:
        """
        P4-A3: alpha_state / coverage / calibration을 size에 반영.
        조건부 sizing의 우위 확인.
        """
        # Base size from forecast strength
        base_size = self.strength_bucket_policy(forecast)
        
        # Alpha confidence adjustment
        alpha_factor = 0.5 + 0.5 * (alpha_score_norm.clip(-1, 1) + 1) / 2
        
        # Coverage adjustment (있는 경우)
        if coverage is not None:
            coverage_factor = coverage.clip(0.5, 1.5)
        else:
            coverage_factor = 1.0
        
        return base_size * alpha_factor * coverage_factor
```

---

## WS-4B: Position Multiplier Replay & Path+Position Combo

```python
# src/strategy/combined_strategy.py

class CombinedCalibrationStrategy:
    """
    Path calibration + Position sizing 결합.
    Phase 1에서 검증된 multiplier를 전략층에 재검증.
    """
    
    def apply_full_calibration(
        self,
        base_forecast: pd.Series,
        alpha_score_norm: pd.Series,
        alpha_state: pd.Series,
        impact: float = 0.5
    ) -> pd.DataFrame:
        """
        Path와 Position을 결합하되 반드시 별도 기록.
        결합 효과 분해 가능해야 함.
        """
        # Path adjustment
        path_mult = PathMultiplier()
        path_adjusted = pd.Series([
            path_mult.apply(
                base_forecast.iloc[i],
                path_mult.compute_multiplier(
                    base_forecast.iloc[i],
                    alpha_score_norm.iloc[i],
                    impact
                )
            )
            for i in range(len(base_forecast))
        ], index=base_forecast.index)
        
        # Position adjustment
        pos_mult = PositionMultiplier()
        position_sizes = pd.Series([
            pos_mult.compute_position_size(1.0, state, impact)
            for state in alpha_state
        ], index=alpha_state.index)
        
        return pd.DataFrame({
            "base_forecast": base_forecast,
            "path_adjusted": path_adjusted,
            "position_size": position_sizes,
            "final_signal": path_adjusted * position_sizes,
            "alpha_score_norm": alpha_score_norm,
            "alpha_state": alpha_state
        })
```

---

## WS-4C: Cost / Turnover / Slippage

```python
# src/strategy/cost_model.py

class TransactionCostModel:
    """
    현실 비용 반영 후 성과 검증.
    비용 차감 후에도 edge가 남는지 확인.
    """
    
    SLIPPAGE_SCENARIOS = [0, 10, 25, 50]  # basis points
    
    def apply_turnover_penalty(
        self,
        positions: pd.Series,
        min_change_threshold: float = 0.05
    ) -> pd.Series:
        """
        최소 변경폭 미만의 포지션 변경은 무시.
        불필요한 리밸런싱 방지.
        """
        smoothed = positions.copy()
        prev = positions.iloc[0]
        
        for i in range(1, len(positions)):
            change = abs(positions.iloc[i] - prev)
            if change < min_change_threshold:
                smoothed.iloc[i] = prev  # 변경 무시
            else:
                prev = positions.iloc[i]
        
        return smoothed
    
    def compute_net_returns(
        self,
        gross_returns: pd.Series,
        positions: pd.Series,
        slippage_bps: float = 10
    ) -> pd.Series:
        """슬리피지 반영 순수익률"""
        turnover = positions.diff().abs()
        cost = turnover * slippage_bps / 10000
        return gross_returns - cost
    
    def run_slippage_stress_test(
        self,
        gross_returns: pd.Series,
        positions: pd.Series
    ) -> pd.DataFrame:
        """0/10/25/50 bps 비용 민감도 분석"""
        results = []
        for bps in self.SLIPPAGE_SCENARIOS:
            net = self.compute_net_returns(gross_returns, positions, bps)
            results.append({
                "slippage_bps": bps,
                "sharpe": compute_sharpe(net),
                "calmar": compute_calmar(net),
                "max_dd": compute_max_drawdown(net),
                "net_return_annualized": net.mean() * 52
            })
        return pd.DataFrame(results)
```

---

## WS-4D: Risk Overlay

```python
# src/strategy/risk_overlay.py

class RiskOverlay:
    """
    Beta cap, stop logic, exposure floor/ceiling.
    테일 리스크 제어.
    """
    
    def __init__(
        self,
        max_gross_exposure: float = 1.0,
        drawdown_brake_threshold: float = -0.15,
        beta_cap: float = 1.5
    ):
        self.max_gross_exposure = max_gross_exposure
        self.drawdown_brake_threshold = drawdown_brake_threshold
        self.beta_cap = beta_cap
    
    def apply(
        self,
        raw_positions: pd.Series,
        cumulative_returns: pd.Series
    ) -> pd.Series:
        """
        위험 조건 발동 시 포지션 축소.
        """
        adjusted = raw_positions.copy()
        
        for i in range(len(raw_positions)):
            # Drawdown brake
            if cumulative_returns.iloc[i] < self.drawdown_brake_threshold:
                adjusted.iloc[i] = raw_positions.iloc[i] * 0.5  # 50% 축소
            
            # Gross exposure cap
            if abs(adjusted.iloc[i]) > self.max_gross_exposure:
                adjusted.iloc[i] = np.sign(adjusted.iloc[i]) * self.max_gross_exposure
        
        return adjusted
```

---

## 전략 성과 평가 지표

```python
# src/strategy/performance_metrics.py

def compute_strategy_scorecard(
    returns: pd.Series,
    positions: pd.Series,
    benchmark_returns: pd.Series | None = None
) -> dict:
    """
    전략 품질 종합 평가.
    반드시 비용 차감 후 수치로만 해석.
    """
    weekly_turnover = positions.diff().abs().mean()
    
    return {
        # Risk-adjusted returns
        "sharpe_ratio": compute_sharpe(returns),
        "sortino_ratio": compute_sortino(returns),
        "calmar_ratio": compute_calmar(returns),
        
        # Risk metrics
        "max_drawdown": compute_max_drawdown(returns),
        "downside_deviation": compute_downside_deviation(returns),
        "var_95": returns.quantile(0.05),
        
        # Trading metrics
        "weekly_turnover": weekly_turnover,
        "win_rate": (returns > 0).mean(),
        
        # Explainability check
        "explainable": weekly_turnover < 0.5  # 과도한 리밸런싱 여부
    }
```

---

## 전략 승격 기준

```python
STRATEGY_PROMOTION_CRITERIA = {
    "min_sharpe_improvement": 0.20,         # 비용 차감 후 Sharpe +0.20
    "min_dd_improvement": 0.10,             # Max DD 10% 이상 개선
    "max_weekly_turnover": 0.50,            # 주간 turnover 50% 이하
    "min_regime_consistency": 1,            # stress or equilibrium 중 1개 강점
    "explainability_required": True         # 3개 문장 이내 근거 서술 가능
}
```

## ✅ G5-In 통과 조건
```
□ Sign-only policy (A1) 기준선 확립
□ Position multiplier (B1) — DD 10% 이상 개선 확인
□ 비용 반영 후 Sharpe +0.20 달성하는 policy 1개 이상 확인
□ Slippage stress test (0~50bps) 완료
□ Regime-conditioned strategy diagnostics 완료
□ 포지션 결정 근거 3개 문장 이내 서술 가능
```
