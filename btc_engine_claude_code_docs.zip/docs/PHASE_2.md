# PHASE_2.md — Signal Expansion

> **담당 서브에이전트**: D  
> **기간**: W5~W8  
> **선행 조건**: Gate C 통과 (Phase 1 완료, D1~D5 판정 완료)  
> **Gate**: G2-In (승격 신호팩 1개 이상 + invalid signal 제거)

---

## 🎯 목적

신호를 많이 넣는 것이 아니라 **어떤 신호팩이 어느 horizon/regime에서 유효한지 분리하여 승격**.

---

## Workstream 구조

| WS | 주제 | 기간 |
|----|------|------|
| WS-2A | Global M2 composite | Week 1 |
| WS-2B | Derivatives structure pack | Week 2 |
| WS-2C | OHLC derived pack | Week 1 (저비용 우선) |
| WS-2D | Controlled on-chain admission | Week 3 |
| WS-2E | Pack competition & promotion | Week 4 |

---

## WS-2A: Global M2

```python
# src/data/signals/global_m2.py

class GlobalM2Signal:
    """
    Fed + ECB + BoJ + PBoC 기반 broad liquidity composite.
    중기 8w/13w horizon 유효성 검증 목적.
    """
    
    CENTRAL_BANKS = ["fed", "ecb", "boj", "pboc"]
    
    def compute_composite(
        self,
        m2_data: dict[str, pd.Series],
        method: str = "usd_adjusted"  # "equal_weight" | "usd_adjusted"
    ) -> pd.Series:
        """글로벌 M2 composite 계산"""
        ...
    
    def compute_roc(
        self,
        composite: pd.Series,
        windows: list[int] = [4, 8, 13]  # weeks
    ) -> pd.DataFrame:
        """Rate of Change 계산"""
        ...

# 실험: P2-A1 (baseline), P2-A2 (USD-adjusted), P2-A3 (lead/lag sweep)
EXPERIMENTS_P2A = [
    {"id": "P2-A1", "method": "equal_weight", 
     "target_horizons": [8, 13], "benchmark": "core_macro"},
    {"id": "P2-A2", "method": "usd_adjusted",
     "check": "liq_z 중복 여부 확인"},
    {"id": "P2-A3", "windows": [4, 8, 13],
     "goal": "가장 안정적인 선행 창 선택"}
]
```

---

## WS-2B: Derivatives Structure Pack

```python
# src/data/signals/derivatives.py

class DerivativesSignal:
    """
    Funding + OI + Basis 기반 단기 positioning signal.
    4w/8w short-horizon conditional lift 목적.
    """
    
    def compute_funding_features(self, funding_series: pd.Series) -> pd.DataFrame:
        return pd.DataFrame({
            "funding_8w_ma": funding_series.rolling(8).mean(),
            "funding_z": zscore(funding_series),
            "funding_reversal": detect_reversal(funding_series),
            "funding_asymmetry": compute_asymmetry(funding_series)
        })
    
    def compute_oi_features(self, oi_series: pd.Series) -> pd.DataFrame:
        return pd.DataFrame({
            "oi_pct_change": oi_series.pct_change(),
            "oi_deleveraging_proxy": detect_deleveraging(oi_series)
        })

# 실험: P2-B1 (Funding only), P2-B2 (Funding+OI), P2-B3 (Basis/perp premium)
```

---

## WS-2C: OHLC Derived Pack

```python
# src/data/signals/ohlc_derived.py

class OHLCDerivedSignal:
    """
    저비용 시장구조 feature.
    운영비용 거의 없이 재현 가능한 보강 여부 확인.
    """
    
    def compute_features(self, ohlcv: pd.DataFrame) -> pd.DataFrame:
        return pd.DataFrame({
            "weekly_range": (ohlcv["high"] - ohlcv["low"]) / ohlcv["close"],
            "body_ratio": abs(ohlcv["close"] - ohlcv["open"]) / 
                         (ohlcv["high"] - ohlcv["low"] + 1e-8),
            "close_position": (ohlcv["close"] - ohlcv["low"]) / 
                             (ohlcv["high"] - ohlcv["low"] + 1e-8),
            "volume_z": zscore(ohlcv["volume"].rolling(26).apply(np.mean))
        })
```

---

## Pack Promotion Criteria (고정 기준)

```python
PACK_PROMOTION_CRITERIA = {
    "target_horizon_lift": {
        "ic_improvement": 0.03,        # IC +0.03 이상
        "sign_accuracy_improvement": 0.02  # 또는 sign accuracy +2%p 이상
    },
    "side_effect_control": {
        "max_non_target_degradation": -0.01  # 비타깃 horizon IC -0.01 이하 악화 금지
    },
    "slice_consistency": {
        "min_slices_positive": 2  # macro_regime or alpha_state slice 2개 이상 같은 방향
    },
    "data_stability": True,   # 결측/수정/지연 규칙 명확, live 수급 가능
    "explainability": True    # feature 의미와 실패 원인 설명 가능
}

def evaluate_pack_promotion(pack_results: pd.DataFrame) -> dict:
    """
    신호팩 승격/보류/폐기 결정.
    """
    decision = "PROMOTE"
    reasons = []
    
    # 1. Target horizon lift
    target_lift = (
        pack_results["ic_delta"].max() >= PACK_PROMOTION_CRITERIA["target_horizon_lift"]["ic_improvement"] or
        pack_results["sign_acc_delta"].max() >= PACK_PROMOTION_CRITERIA["target_horizon_lift"]["sign_accuracy_improvement"]
    )
    if not target_lift:
        decision = "REJECT"
        reasons.append("타깃 horizon lift 미충족")
    
    # 2. 비타깃 horizon 악화 확인
    non_target_degradation = pack_results[~pack_results["is_target_horizon"]]["ic_delta"].min()
    if non_target_degradation < PACK_PROMOTION_CRITERIA["side_effect_control"]["max_non_target_degradation"]:
        decision = "HOLD"
        reasons.append(f"비타깃 horizon IC 악화: {non_target_degradation:.3f}")
    
    return {"decision": decision, "reasons": reasons, "metrics": pack_results.to_dict()}
```

## ✅ G2-In 통과 조건
```
□ 승격 후보 신호팩 1개 이상 확정
□ invalid signal (무효 신호) 제거 목록 작성
□ Pack tournament (P2-E1) 완료 → 승격/보류/폐기 결정표 생성
□ Phase 3 입력 스펙 고정
```
