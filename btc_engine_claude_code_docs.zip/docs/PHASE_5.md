# PHASE_5.md — Reliability / Speed / Observability

> **담당 서브에이전트**: G  
> **기간**: W15~W16  
> **선행 조건**: G5-In (전략 규칙 초안 + live artifact 구조 확정)  
> **Gate**: G6-In

---

## 🎯 목적

> "잘못된 입력을 거부하고, 실패를 남기고, 오늘의 예측을 인간이 이해할 수 있어야 한다."

속도, 안정성, 설명 가능성은 세 개가 동시에 올라가야 함.

---

## WS-5A: Runtime Decomposition

```python
# src/pipeline/profiler.py

import time
import functools

class RuntimeProfiler:
    """각 단계별 실행 시간 측정 및 bottleneck 식별"""
    
    def __init__(self):
        self.timings = {}
    
    def measure(self, stage_name: str):
        """decorator로 사용"""
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                start = time.perf_counter()
                result = func(*args, **kwargs)
                elapsed = time.perf_counter() - start
                self.timings[stage_name] = elapsed
                return result
            return wrapper
        return decorator
    
    def get_profile_report(self) -> pd.DataFrame:
        """runtime_profile.csv 생성"""
        return pd.DataFrame([
            {"stage": k, "seconds": v, "pct": v / sum(self.timings.values()) * 100}
            for k, v in sorted(self.timings.items(), key=lambda x: -x[1])
        ])
    
    def identify_hotspots(self, top_n: int = 3) -> list[str]:
        """가장 느린 구간 상위 N개"""
        sorted_timings = sorted(self.timings.items(), key=lambda x: -x[1])
        return [stage for stage, _ in sorted_timings[:top_n]]


# 사용 예시
profiler = RuntimeProfiler()

@profiler.measure("feature_build")
def build_features(panel): ...

@profiler.measure("model_fit")
def fit_models(X, y): ...

@profiler.measure("ensemble")
def run_ensemble(predictions): ...
```

---

## WS-5B: Cache & Incremental Compute

```python
# src/pipeline/cache.py (확장)

class SmartCacheManager:
    """
    feature/model/artifact cache 규칙 고정.
    data_version + config_hash 기반 무효화.
    """
    
    def __init__(self, cache_dir: str = ".cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.hit_count = 0
        self.miss_count = 0
    
    def get_cache_stats(self) -> dict:
        """cache hit rate 추적"""
        total = self.hit_count + self.miss_count
        return {
            "hit_count": self.hit_count,
            "miss_count": self.miss_count,
            "hit_rate": self.hit_count / total if total > 0 else 0
        }
    
    def invalidate_on_schema_drift(
        self,
        current_schema: list[str],
        cached_schema: list[str]
    ) -> bool:
        """schema 변경 시 cache 자동 무효화"""
        if set(current_schema) != set(cached_schema):
            self.invalidate_all()
            return True
        return False
    
    def get_refit_schedule(
        self,
        performance_history: pd.DataFrame,
        ic_degradation_threshold: float = -0.05
    ) -> str:
        """
        성능 저하 감지 시 재학습 스케줄 결정.
        매주 vs N주마다 재학습 비교.
        """
        recent_ic = performance_history["ic"].tail(4).mean()
        baseline_ic = performance_history["ic"].mean()
        
        if recent_ic - baseline_ic < ic_degradation_threshold:
            return "immediate_refit"
        return "scheduled_refit"
```

---

## WS-5C: Data Quality Gate (강화)

```python
# src/data/quality_gate.py (강화)

class EnhancedDataQualityGate:
    """
    live mode: 차단 + 경고 분리
    research mode: 경고만
    """
    
    def run_full_check(
        self,
        panel: pd.DataFrame,
        as_of_date: pd.Timestamp,
        mode: str = "live"
    ) -> dict:
        
        results = {
            "gate_passed": True,
            "blocking_issues": [],
            "warnings": [],
            "checks": {}
        }
        
        # 1. Missing/Stale check
        results["checks"]["missing"] = self._check_missing(panel)
        results["checks"]["stale"] = self._check_stale(panel, as_of_date)
        
        # 2. Outlier check (경고만)
        outlier_flags = self._check_outliers(panel)
        if outlier_flags:
            results["warnings"].append(f"이상값 감지: {outlier_flags}")
        
        # 3. Panel integrity
        results["checks"]["integrity"] = self._check_integrity(panel)
        
        # 4. 주간 cut-off 전 미완성 데이터 → neutral 처리
        incomplete = self._detect_incomplete_weekly_data(panel, as_of_date)
        if incomplete:
            results["warnings"].append(f"주간 집계 미완성: {incomplete} → neutral 처리")
        
        # Blocking 조건 집계
        for check_name, check_result in results["checks"].items():
            if not check_result["passed"] and mode == "live":
                results["blocking_issues"].append(check_result["reason"])
                results["gate_passed"] = False
        
        return results
    
    def _check_missing(self, panel: pd.DataFrame) -> dict:
        missing_ratio = panel.isnull().mean().mean()
        return {
            "passed": missing_ratio < 0.10,
            "missing_ratio": missing_ratio,
            "reason": f"결측률 {missing_ratio:.1%} > 10%" if missing_ratio >= 0.10 else None
        }
    
    def _check_outliers(self, panel: pd.DataFrame) -> list[str]:
        """z > 5 이상 극단값 탐지"""
        flagged = []
        for col in panel.select_dtypes(include=[np.number]).columns:
            z = np.abs((panel[col] - panel[col].mean()) / (panel[col].std() + 1e-8))
            if (z > 5).any():
                flagged.append(f"{col}: {(z > 5).sum()}개 이상값")
        return flagged
```

---

## WS-5D: Structured Logging & Failure Drill

```python
# src/pipeline/logger.py

import logging
import json

class StructuredLogger:
    """JSON 형식 structured logging"""
    
    def __init__(self, run_id: str, log_file: str = "logs/runtime.log"):
        self.run_id = run_id
        self.log_file = Path(log_file)
        self.log_file.parent.mkdir(exist_ok=True)
    
    def log_event(self, level: str, event: str, **kwargs):
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "run_id": self.run_id,
            "level": level,
            "event": event,
            **kwargs
        }
        with open(self.log_file, "a") as f:
            f.write(json.dumps(entry) + "\n")
    
    def log_failure(self, stage: str, error: Exception, **context):
        """실패는 반드시 structured log로 보존"""
        self.log_event(
            "ERROR",
            "stage_failure",
            stage=stage,
            error_type=type(error).__name__,
            error_message=str(error),
            **context
        )
        
        # error artifact 자동 저장
        error_artifact = {
            "run_id": self.run_id,
            "stage": stage,
            "error": str(error),
            "timestamp": datetime.utcnow().isoformat(),
            "context": context
        }
        error_file = Path(f"artifacts/runs/{self.run_id}/error_{stage}.json")
        with open(error_file, "w") as f:
            json.dump(error_artifact, f, indent=2)


# Failure injection drill (WP-5D1)
def run_failure_drill(runner: ExperimentRunner):
    """
    소스 누락 / schema mismatch / stale file 강제 발생 테스트.
    graceful fail 여부 확인.
    """
    scenarios = [
        {"name": "missing_mvrv", "action": "remove mvrv column"},
        {"name": "schema_mismatch", "action": "add unexpected column"},
        {"name": "stale_data", "action": "use 30-day-old panel"}
    ]
    
    results = {}
    for scenario in scenarios:
        try:
            # 각 시나리오 주입 후 실행
            result = inject_and_run(runner, scenario)
            results[scenario["name"]] = {
                "graceful_fail": True,
                "error_artifact_saved": check_error_artifact(runner.run_id, scenario["name"])
            }
        except SystemExit:
            results[scenario["name"]] = {"graceful_fail": False}
    
    return results
```

---

## WS-5E: Explainability UI

```python
# src/ui/explanation_panel.py

class TodayExplanationPanel:
    """
    오늘 예측의 기여 신호, size, 위험요인을 한 화면에 표출.
    today panel만 보고도 예측 근거 파악 가능해야 함.
    """
    
    def render(
        self,
        today_forecast: dict,
        alpha_components: dict,
        position_size: float,
        prev_forecast: dict | None = None
    ):
        """
        Today View: 현재 예측 상태
        Delta View: 직전 run 대비 변화 원인
        Alert View: 위험 요인
        """
        st.header("📊 오늘의 BTC 예측 요약")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Alpha State", today_forecast["alpha_state"])
            st.metric("Score Norm", f"{today_forecast['alpha_score_norm']:.2f}")
        
        with col2:
            st.metric("4주 예측", f"{today_forecast['h4']:.1%}")
            st.metric("13주 예측", f"{today_forecast['h13']:.1%}")
        
        with col3:
            st.metric("권장 포지션 크기", f"{position_size:.0%}")
        
        # Component breakdown
        st.subheader("Alpha 기여 분해")
        self._render_component_breakdown(alpha_components)
        
        # Delta view (이전 대비 변화)
        if prev_forecast:
            st.subheader("직전 대비 변화")
            self._render_delta_view(today_forecast, prev_forecast)
        
        # 3개 문장 이내 근거 서술 (자동 생성)
        st.subheader("판단 근거 요약")
        st.write(self._generate_rationale(today_forecast, alpha_components))
    
    def _generate_rationale(self, forecast: dict, components: dict) -> str:
        """포지션 결정 근거를 3개 문장 이내로 자동 생성"""
        rationale = []
        
        if forecast["alpha_state"] in ["BULLISH", "STRONG_BULL"]:
            rationale.append(
                f"현재 Alpha State는 {forecast['alpha_state']}으로, "
                f"온체인/파생 신호가 강세를 지지합니다."
            )
        
        dominant_signal = max(components, key=lambda k: abs(components[k]))
        rationale.append(
            f"가장 큰 기여 신호는 {dominant_signal} ({components[dominant_signal]:+.1f}점)입니다."
        )
        
        rationale.append(
            f"이에 따라 기본 포지션에서 {forecast['position_multiplier']:.0%} 크기를 권장합니다."
        )
        
        return " ".join(rationale)
```

## ✅ G6-In 통과 조건
```
□ Runtime profile: 가장 느린 구간 상위 3개 식별 및 최적화
□ Cache hit rate: 재실행 시 cache 정상 작동
□ Data quality gate: 차단/경고 규칙 모두 정상 동작
□ Failure drill: 3개 시나리오 모두 graceful fail 확인
□ Run-card logging: run_id/config_hash/latency 자동 저장
□ Today explanation panel: 3개 문장 이내 근거 자동 생성
□ Delta view: 직전 대비 변화 원인 표시
```
