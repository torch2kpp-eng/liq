# PHASE_6.md — Champion Config & Operating Mode Split

> **담당 서브에이전트**: H  
> **기간**: W17~W18 (ongoing)  
> **선행 조건**: G6-In 통과 (운영형 run-card + 모드 분리 기준 확정)  
> **Gate**: 없음 (ongoing governance)

---

## 🎯 목적

> "모델 대회가 아니라 운영 거버넌스 단계. 어떤 config가 어떤 조건에서 챔피언인지, 그 상태가 언제 무너지는지를 운영 체계 안에 넣는 것."

---

## WS-6A: Champion Registry

```python
# src/governance/champion_registry.py

import yaml
from dataclasses import dataclass, asdict

@dataclass
class ChampionConfig:
    """단일 champion 설정"""
    config_id: str
    version: str
    model_type: str                    # "ecm" | "ridge" | "lgbm" | "ensemble"
    feature_pack_version: str
    score_spec_version: str
    alpha_pack: str                     # "short" | "long" | "unified"
    target_horizons: list[int]
    promotion_date: str
    oos_sharpe: float
    oos_max_dd: float
    oos_ic: float
    rationale: str                      # 승격 근거 (3~5문장)
    rollback_trigger: dict              # 롤백 발동 조건


@dataclass 
class ChampionRegistry:
    """
    overall champion + horizon별 segment champion 관리.
    너무 많으면 운영 불가 — overall 1개 + segment 소수로 제한.
    """
    
    overall_champion: ChampionConfig
    segment_champions: dict[str, ChampionConfig]  # {"h4": config, "h13": config, ...}
    registry_version: str
    last_updated: str
    
    def save(self, path: str = "champion_registry.yaml"):
        with open(path, "w") as f:
            yaml.dump(asdict(self), f, default_flow_style=False, allow_unicode=True)
    
    @classmethod
    def load(cls, path: str = "champion_registry.yaml") -> "ChampionRegistry":
        with open(path, "r") as f:
            data = yaml.safe_load(f)
        return cls(**data)
    
    def get_active_champion(self, horizon: int | None = None) -> ChampionConfig:
        """
        horizon 지정 시 segment champion 반환.
        없으면 overall champion 반환.
        """
        if horizon and f"h{horizon}" in self.segment_champions:
            return self.segment_champions[f"h{horizon}"]
        return self.overall_champion


# champion_registry.yaml 예시 구조
REGISTRY_TEMPLATE = """
overall_champion:
  config_id: "champ_v1_ecm_full"
  version: "1.0"
  model_type: "ecm"
  feature_pack_version: "v2.0_with_m2_derivatives"
  score_spec_version: "v1.0"
  alpha_pack: "unified"
  target_horizons: [4, 8, 13, 26]
  promotion_date: "2026-XX-XX"
  oos_sharpe: TBD
  oos_max_dd: TBD
  oos_ic: TBD
  rationale: "ECM이 전 horizon에서 가장 안정적인 성능을 보임. 알파 interaction 추가 시 state-conditioned lift 재현됨."
  rollback_trigger:
    rolling_ic_drop: -0.10
    max_dd_breach: -0.30
    latency_breach_seconds: 300

segment_champions:
  h4:
    config_id: "champ_v1_ridge_short"
    alpha_pack: "short"
    # ...
  h13:
    config_id: "champ_v1_ecm_long"
    alpha_pack: "long"
    # ...
"""
```

---

## WS-6B: Shadow Run & Promotion

```python
# src/governance/shadow_runner.py

class ShadowRunner:
    """
    신규 후보를 기존 champion과 병렬 실행하여 승격 전 drift 확인.
    실전 전 최소 4주 shadow run 의무.
    """
    
    MIN_SHADOW_WEEKS = 4
    
    def run_parallel(
        self,
        champion_config: ChampionConfig,
        challenger_config: ChampionConfig,
        n_weeks: int = None
    ) -> dict:
        """
        Champion과 Challenger를 동일 데이터로 병렬 실행.
        """
        weeks = n_weeks or self.MIN_SHADOW_WEEKS
        
        champion_results = []
        challenger_results = []
        
        for week in range(weeks):
            champ_pred = run_config(champion_config, week_offset=week)
            chal_pred = run_config(challenger_config, week_offset=week)
            
            champion_results.append(champ_pred)
            challenger_results.append(chal_pred)
        
        return {
            "champion": pd.concat(champion_results),
            "challenger": pd.concat(challenger_results),
            "comparison": self._compare_results(champion_results, challenger_results)
        }
    
    def _compare_results(self, champion, challenger) -> dict:
        """Shadow 기간 성능 비교"""
        return {
            "sharpe_delta": compute_sharpe(challenger) - compute_sharpe(champion),
            "dd_delta": compute_max_drawdown(challenger) - compute_max_drawdown(champion),
            "ic_delta": compute_ic(challenger) - compute_ic(champion),
            "recommendation": "PROMOTE" if all([
                compute_sharpe(challenger) > compute_sharpe(champion),
                compute_max_drawdown(challenger) > compute_max_drawdown(champion)
            ]) else "HOLD"
        }


class PromotionReview:
    """
    Shadow run 완료 후 승격 검토.
    효과 크기 + 안정성 + explainability + ops cost 종합.
    """
    
    PROMOTION_CHECKLIST = [
        "shadow_run_completed",
        "sharpe_improvement_positive",
        "no_dd_degradation",
        "explainability_verified",
        "ops_cost_acceptable",
        "data_stability_confirmed"
    ]
    
    def review(
        self,
        shadow_results: dict,
        challenger_config: ChampionConfig
    ) -> dict:
        checks = {}
        
        checks["shadow_run_completed"] = len(shadow_results["challenger"]) >= self.MIN_SHADOW_WEEKS * 52
        checks["sharpe_improvement_positive"] = shadow_results["comparison"]["sharpe_delta"] > 0
        checks["no_dd_degradation"] = shadow_results["comparison"]["dd_delta"] >= 0
        checks["explainability_verified"] = bool(challenger_config.rationale)
        checks["ops_cost_acceptable"] = True  # 수동 확인
        checks["data_stability_confirmed"] = True  # 수동 확인
        
        all_passed = all(checks.values())
        
        return {
            "decision": "PROMOTE" if all_passed else "HOLD",
            "checks": checks,
            "failed_checks": [k for k, v in checks.items() if not v]
        }
```

---

## WS-6C/D: Production Mode & Research Mode Split

```python
# src/config/mode_config.py

from enum import Enum

class EngineMode(Enum):
    RESEARCH = "research"
    PRODUCTION = "production"


PRODUCTION_CONFIG = {
    "mode": EngineMode.PRODUCTION,
    "allowed_features": "champion_feature_pack_only",
    "allowed_models": ["ecm", "ridge"],   # 검증된 모델만
    "cache_policy": "strict",
    "artifact_verbosity": "minimal",       # 핵심 산출물만
    "refit_schedule": "weekly",
    "quality_gate": "blocking",            # 실패 시 실행 중단
    "explainability_panel": True,
    "rollback_enabled": True
}

RESEARCH_CONFIG = {
    "mode": EngineMode.RESEARCH,
    "allowed_features": "all",             # 실험적 신호 포함
    "allowed_models": ["ecm", "ridge", "lgbm", "ensemble", "hmm"],
    "cache_policy": "flexible",
    "artifact_verbosity": "verbose",       # 모든 실험 artifact
    "refit_schedule": "on_demand",
    "quality_gate": "warning_only",        # 경고만, 중단 없음
    "ablation_enabled": True,
    "heavy_backtest_enabled": True
}


class ModeGuard:
    """연구/운영 모드 혼용 방지"""
    
    def validate_config_for_mode(
        self,
        config: dict,
        mode: EngineMode
    ) -> dict:
        """
        Production 모드에서 연구용 설정 사용 시 차단.
        두 모드를 같은 config로 섞지 않는다.
        """
        allowed = PRODUCTION_CONFIG if mode == EngineMode.PRODUCTION else RESEARCH_CONFIG
        
        violations = []
        
        if mode == EngineMode.PRODUCTION:
            if config.get("allowed_models") != allowed["allowed_models"]:
                violations.append("Production 모드에서 미검증 모델 사용 금지")
            
            if config.get("quality_gate") != "blocking":
                violations.append("Production 모드에서 quality gate는 blocking이어야 함")
        
        return {
            "valid": len(violations) == 0,
            "violations": violations
        }
```

---

## WS-6E: Rollback & Governance

```python
# src/governance/rollback_manager.py

class RollbackManager:
    """
    성능 저하 감지 및 이전 champion으로 자동 롤백.
    """
    
    GUARDRAIL_THRESHOLDS = {
        "rolling_ic_drop": -0.10,        # 최근 4주 IC가 기준 대비 0.10 이상 하락
        "max_dd_breach": -0.30,          # 최대 낙폭 30% 초과
        "latency_breach_seconds": 300,   # 실행 시간 5분 초과
        "data_gate_failures": 3          # 연속 3회 data gate 실패
    }
    
    def check_guardrails(
        self,
        recent_metrics: pd.DataFrame,
        current_config: ChampionConfig,
        registry: ChampionRegistry
    ) -> dict:
        """
        Guardrail 위반 여부 확인. 숫자로 관리.
        """
        violations = []
        
        # Rolling IC check
        recent_ic = recent_metrics["ic"].tail(4).mean()
        baseline_ic = current_config.oos_ic
        
        if recent_ic - baseline_ic < self.GUARDRAIL_THRESHOLDS["rolling_ic_drop"]:
            violations.append({
                "type": "rolling_ic_drop",
                "value": recent_ic - baseline_ic,
                "threshold": self.GUARDRAIL_THRESHOLDS["rolling_ic_drop"]
            })
        
        # DD check
        current_dd = recent_metrics["cumulative_return"].min()
        if current_dd < self.GUARDRAIL_THRESHOLDS["max_dd_breach"]:
            violations.append({
                "type": "max_dd_breach",
                "value": current_dd,
                "threshold": self.GUARDRAIL_THRESHOLDS["max_dd_breach"]
            })
        
        return {
            "guardrail_breached": len(violations) > 0,
            "violations": violations,
            "action": "ROLLBACK" if violations else "CONTINUE"
        }
    
    def execute_rollback(
        self,
        registry: ChampionRegistry,
        fallback_config_id: str
    ) -> bool:
        """
        이전 champion으로 즉시 복귀.
        목표 복구 시간: 10분 이내.
        """
        # 현재 champion 백업
        backup_path = f"artifacts/rollback/{datetime.now().strftime('%Y%m%d_%H%M%S')}_backup.yaml"
        registry.save(backup_path)
        
        # fallback config 로딩
        fallback = registry.segment_champions.get(fallback_config_id)
        if fallback is None:
            raise ValueError(f"Fallback config {fallback_config_id} not found")
        
        # Registry 업데이트
        registry.overall_champion = fallback
        registry.save()
        
        logger.warning(f"ROLLBACK 실행: {fallback_config_id}로 복귀")
        return True


# rollback_playbook.md 자동 생성
ROLLBACK_PLAYBOOK_TEMPLATE = """
# Rollback Playbook

## 롤백 트리거 조건
- Rolling IC: 최근 4주 IC가 기준 대비 -0.10 이상 하락
- Max DD: -30% 이하
- Latency: 5분 이상
- Data gate 연속 3회 실패

## 롤백 절차
1. guardrail_check.py 실행 → 위반 항목 확인
2. rollback_manager.execute_rollback() 실행
3. 롤백 후 shadow_runner로 원인 분석
4. promotion_review 재실행 후 재승격 여부 결정

## 복구 목표 시간
- 감지: 실시간 (자동)
- 실행: 10분 이내
- 확인: 30분 이내

## 연락 체계
- 자동 롤백 후 로그 확인: logs/rollback.log
- 원인 분석: artifacts/rollback/{timestamp}_backup.yaml
"""
```

---

## Champion Monitoring (지속 운영)

```python
# src/governance/champion_monitor.py

class ChampionMonitor:
    """
    운영 중인 champion의 성능 지속 추적.
    """
    
    MONITORING_METRICS = [
        "rolling_ic",       # 최근 4/8/13주 rolling IC
        "rolling_sharpe",   # 최근 26주 rolling Sharpe
        "max_drawdown",     # 현재 누적 최대 낙폭
        "error_drift",      # 예측 오차 시계열 추세
        "latency",          # 주간 실행 시간
        "data_gate_status"  # 데이터 품질 상태
    ]
    
    def generate_weekly_report(
        self,
        run_results: dict,
        registry: ChampionRegistry
    ) -> dict:
        """주간 champion 성능 리포트 자동 생성"""
        
        current_metrics = {
            metric: compute_metric(run_results, metric)
            for metric in self.MONITORING_METRICS
        }
        
        # Guardrail 체크
        guardrail_check = RollbackManager().check_guardrails(
            recent_metrics=pd.DataFrame([current_metrics]),
            current_config=registry.overall_champion,
            registry=registry
        )
        
        return {
            "week": datetime.now().strftime("%Y-W%V"),
            "champion_id": registry.overall_champion.config_id,
            "metrics": current_metrics,
            "guardrail_status": guardrail_check,
            "recommendation": guardrail_check["action"]
        }
```

---

## ✅ Phase 6 완료 조건 (ongoing governance)

```
초기 설정 (W17~W18):
□ champion_registry.yaml 초안 작성
□ Production config / Research config 분리 완료
□ ModeGuard 구현 — 혼용 방지
□ Shadow runner 4주 이상 실행 준비 완료
□ Rollback playbook 문서화
□ Rollback drill (P6-E1) 1회 실행

지속 운영 (weekly):
□ Champion monitoring 주간 리포트 자동 생성
□ Guardrail 자동 체크
□ 이상 감지 시 rollback 30분 이내 완료
□ 새 challenger 발생 시 shadow run → promotion review 절차 준수
```

---

## 최종 운영 체계 요약

```
Research Mode (탐색):
  └── 새 신호팩 실험 → ablation → pack tournament
      ↓ (G2-In 통과 시)
  └── Interaction 실험 → LightGBM/Stacking 평가
      ↓ (G3-In 통과 시)
  └── Shadow run (4주 이상)
      ↓ (Promotion Review 통과 시)
      
Production Mode (운영):
  └── Champion config 고정 실행
  └── Weekly monitoring + guardrail check
  └── 이상 감지 → Rollback (10분 이내)
  └── 롤백 후 원인 분석 → Research Mode로 피드백
```
