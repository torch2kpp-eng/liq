# PHASE_MINUS1.md — Validation Guardrails / Point-in-Time Integrity

> **담당 서브에이전트**: A  
> **기간**: D1~D5  
> **선행 조건**: 없음 (최초 단계)  
> **Gate**: Gate A 통과 후 Phase 0 진입 허용

---

## 🎯 이 Phase의 목적

> "숫자가 오염되지 않도록 만드는 것. 좋은 숫자를 만드는 것이 아님."

Phase -1은 이후 모든 OOS 결과의 **신뢰성 기반**을 만든다.  
여기서 고정하지 않으면 Phase 1 이후의 모든 성능 수치는 해석 불가.

---

## 📋 Work Package 목록

| WP | 핵심 질문 | 우선순위 | 예상 소요 |
|----|-----------|----------|-----------|
| WP-1 | 이 데이터는 언제 알 수 있었는가? | P0 | D1 |
| WP-2 | score_norm은 시점이 달라도 같은 의미인가? | P0 | D2 |
| WP-3 | Phase 1 통과 여부를 무엇으로 판정할 것인가? | P0 | D2 |
| WP-4 | 백테스트는 당시 가용값만 쓰는가? | P1 | D3~D4 |
| WP-5 | 구현이 실제로 적용되었는가? | P1 | D4~D5 |

---

## WP-1: Data Availability Spec

### 구현 목표
`spec/data_availability_spec.md` 파일 생성 및 `src/data/point_in_time.py` 구현

### 데이터 소스별 PIT 규칙 (고정값)

```python
# src/data/point_in_time.py

PIT_RULES = {
    "mvrv": {
        "lag_days": 7,
        "revision_risk": True,
        "reason": "주간 집계 확정 지연 + 소급 수정 안전 마진",
        "freeze_rule": "주 예측일 기준 T-7일 데이터까지만 허용"
    },
    "exchange_reserve": {
        "lag_days": 7,
        "revision_risk": True,
        "reason": "거래소별 집계 정책 변경 및 오류 수정 소급 리스크",
        "freeze_rule": "주 예측일 기준 T-7일 데이터까지만 허용"
    },
    "etf_flow": {
        "lag_days": 2,
        "revision_risk": False,
        "reason": "미국 스팟 ETF T+1 발표 + 1일 안전 마진",
        "freeze_rule": "주 예측일 기준 T-2일 데이터까지만 허용"
    },
    "funding_rate": {
        "lag_days": 0,
        "revision_risk": False,
        "reason": "실시간 가용, 지연 없음",
        "freeze_rule": "실시간 사용 가능. 단 8주 이동평균 계산 시 종료 시점 확인"
    },
    "halving_phase": {
        "lag_days": 0,
        "revision_risk": False,
        "reason": "내장 날짜 로직, 소급 수정 없음",
        "freeze_rule": "실시간 사용 가능"
    }
}


def point_in_time_filter(
    df: pd.DataFrame,
    as_of_date: pd.Timestamp,
    source: str
) -> pd.DataFrame:
    """
    예측 시점(as_of_date) 기준으로 실제 가용한 데이터만 반환.
    
    Args:
        df: 전체 데이터프레임 (date 컬럼 포함)
        as_of_date: 예측 실행 시점
        source: 데이터 소스 키 (PIT_RULES의 키 값)
    
    Returns:
        as_of_date 기준으로 실제 사용 가능한 행만 포함한 df
    
    Raises:
        ValueError: source가 PIT_RULES에 없을 경우
    """
    if source not in PIT_RULES:
        raise ValueError(f"Unknown source: {source}. Must be one of {list(PIT_RULES.keys())}")
    
    lag_days = PIT_RULES[source]["lag_days"]
    cutoff = as_of_date - pd.Timedelta(days=lag_days)
    
    return df[df["date"] <= cutoff].copy()


def apply_all_pit_filters(
    panel: pd.DataFrame,
    as_of_date: pd.Timestamp
) -> pd.DataFrame:
    """
    전체 패널에 모든 소스의 PIT 규칙을 일괄 적용.
    각 소스 컬럼을 해당 lag만큼 shift하여 look-ahead bias 제거.
    """
    result = panel.copy()
    
    source_columns = {
        "mvrv": ["mvrv_z", "mvrv_4w_change"],
        "exchange_reserve": ["reserve_pct_change", "reserve_z"],
        "etf_flow": ["etf_4w_cumulative", "etf_z", "etf_available"],
        "funding_rate": ["funding_8w_ma", "funding_z"],
        "halving_phase": ["halving_phase", "months_since_halving"]
    }
    
    for source, columns in source_columns.items():
        lag_days = PIT_RULES[source]["lag_days"]
        lag_weeks = max(1, lag_days // 7)  # 주간 데이터 기준
        
        for col in columns:
            if col in result.columns and lag_weeks > 0:
                result[col] = result[col].shift(lag_weeks)
    
    return result
```

### 산출물
- [ ] `spec/data_availability_spec.md` (1페이지 표 형태)
- [ ] `src/data/point_in_time.py` (위 코드 구현)
- [ ] `tests/test_point_in_time.py` (unit test)

### Unit Test 필수 케이스

```python
# tests/test_point_in_time.py

def test_mvrv_lag_7_days():
    """MVRV는 T-7일 데이터까지만 사용해야 함"""
    ...

def test_etf_lag_2_days():
    """ETF는 T-2일 데이터까지만 사용해야 함"""
    ...

def test_funding_no_lag():
    """Funding은 lag 없이 실시간 사용 가능"""
    ...

def test_no_future_data_leakage():
    """어떤 소스도 as_of_date 이후 데이터를 반환하지 않아야 함"""
    ...
```

---

## WP-2: Scoring Normalization

### 구현 목표
`src/alpha/scoring.py` 수정 — ETF 포함 6점 고정 분모 적용

### 핵심 코드

```python
# src/alpha/scoring.py

FIXED_MAX_SCORE = 6.0  # ETF 포함 기준 고정 분모 — 절대 변경 금지

COMPONENT_WEIGHTS = {
    "mvrv": {"max": 2, "min": -2},
    "exchange_reserve": {"max": 1, "min": -1},
    "etf_flow": {"max": 1, "min": -1},      # ETF 없으면 score=0, etf_available=0
    "funding_rate": {"max": 1, "min": -1},
    "halving_phase": {"max": 1, "min": -1}
}


def calculate_component_scores(
    mvrv_z: float,
    reserve_pct_change: float,
    etf_z: float | None,
    funding_z: float,
    halving_phase: str,
    etf_available: bool
) -> dict:
    """
    각 컴포넌트의 점수를 계산.
    ETF 미가용 시 etf_score=0, etf_available=False로 처리.
    """
    scores = {}
    
    # MVRV scoring
    if mvrv_z <= 0.0:
        scores["mvrv"] = 2
    elif mvrv_z <= 0.5:
        scores["mvrv"] = 1
    elif mvrv_z >= 7.0:
        scores["mvrv"] = -2
    elif mvrv_z >= 5.0:
        scores["mvrv"] = -1
    else:
        scores["mvrv"] = 0
    
    # Exchange Reserve scoring
    if reserve_pct_change <= -0.03:
        scores["exchange_reserve"] = 1
    elif reserve_pct_change >= 0.03:
        scores["exchange_reserve"] = -1
    else:
        scores["exchange_reserve"] = 0
    
    # ETF Flow scoring (미가용 시 0)
    if not etf_available or etf_z is None:
        scores["etf_flow"] = 0
    elif etf_z >= 0.5:
        scores["etf_flow"] = 1
    elif etf_z <= -0.5:
        scores["etf_flow"] = -1
    else:
        scores["etf_flow"] = 0
    
    # Funding Rate scoring
    if funding_z <= -1.5:
        scores["funding_rate"] = 1
    elif funding_z >= 1.5:
        scores["funding_rate"] = -1
    else:
        scores["funding_rate"] = 0
    
    # Halving Phase scoring
    if halving_phase == "post_mid":
        scores["halving_phase"] = 1
    elif halving_phase == "bear_phase":
        scores["halving_phase"] = -1
    else:
        scores["halving_phase"] = 0
    
    return scores


def calculate_alpha_score_norm(
    component_scores: dict,
    etf_available: bool
) -> tuple[float, str]:
    """
    고정 분모(6.0)로 정규화된 alpha score와 state 반환.
    
    Returns:
        (alpha_score_norm, alpha_state, raw_score)
    """
    raw_score = sum(component_scores.values())
    alpha_score_norm = raw_score / FIXED_MAX_SCORE  # 항상 6.0으로 나눔
    
    # State mapping
    if alpha_score_norm >= 0.55:
        state = "STRONG_BULL"
    elif alpha_score_norm >= 0.20:
        state = "BULLISH"
    elif alpha_score_norm <= -0.55:
        state = "STRONG_BEAR"
    elif alpha_score_norm <= -0.20:
        state = "BEARISH"
    else:
        state = "NEUTRAL"
    
    return alpha_score_norm, state, raw_score
```

### Pre-ETF / Post-ETF 분리 보고 의무

```python
def generate_split_report(
    metrics_df: pd.DataFrame,
    etf_cutoff_date: str = "2024-01-01"
) -> dict:
    """
    반드시 Pre-ETF와 Post-ETF 구간을 분리하여 보고.
    전체 평균만 단독으로 보고하는 것은 금지.
    """
    pre_etf = metrics_df[metrics_df["date"] < etf_cutoff_date]
    post_etf = metrics_df[metrics_df["date"] >= etf_cutoff_date]
    
    return {
        "pre_etf": compute_metrics(pre_etf),
        "post_etf": compute_metrics(post_etf),
        "overall": compute_metrics(metrics_df),  # 참고용, 단독 사용 금지
        "etf_cutoff_date": etf_cutoff_date
    }
```

### 산출물
- [ ] `spec/scoring_spec.md`
- [ ] `src/alpha/scoring.py` (위 코드 구현)
- [ ] `tests/test_scoring.py`

---

## WP-3: Quantified Acceptance Criteria

### 구현 목표
`spec/acceptance_criteria.md` 생성 + `src/validation/acceptance_checker.py` 구현

### 수치 기준 (고정 — 정성 표현 사용 금지)

```python
# src/validation/acceptance_checker.py

ACCEPTANCE_CRITERIA = {
    # 통계 기준
    "min_oos_samples_per_state": 15,
    "min_samples_hard_floor": 10,       # 이하면 해당 state 평가 보류
    "min_delta_ic_vs_neutral": 0.05,    # |ΔIC| > 0.05
    "min_t_stat": 1.5,                  # 또는 t-stat > 1.5
    "min_sign_accuracy_lift": 0.05,     # 50% 대비 +5%p
    
    # 통과 기준
    "min_horizons_passing": 2,          # 4개 horizon 중 최소 2개
    "required_states_differentiated": 1, # BULL or BEAR 중 최소 1개
    
    # 샘플 불균형 처리
    "imbalance_correction": "bootstrap", # "bootstrap" | "stratified"
    
    # Horizon 그룹
    "short_horizons": [4, 8],
    "long_horizons": [13, 26],
    
    # Path multiplier 전용
    "path_eval_condition": "base_correct_only",  # 방향 적중 샘플만 평가
    
    # Position multiplier 전용
    "position_primary_metric": "max_dd",  # Sharpe보다 DD 우선
}


def check_acceptance(
    slice_metrics: pd.DataFrame,
    phase: str,
    verbose: bool = True
) -> dict:
    """
    정량 기준으로 Phase 통과 여부 자동 판정.
    
    Returns:
        {
            "passed": bool,
            "by_horizon": {4: bool, 8: bool, 13: bool, 26: bool},
            "by_state": {"BULLISH": bool, "BEARISH": bool, ...},
            "failures": [str],  # 실패 이유 목록
            "warnings": [str]   # 경고 목록 (보류 state 등)
        }
    """
    result = {"passed": False, "by_horizon": {}, "by_state": {}, 
              "failures": [], "warnings": []}
    
    horizons_passed = 0
    
    for horizon in [4, 8, 13, 26]:
        horizon_data = slice_metrics[slice_metrics["horizon"] == horizon]
        
        for state in ["BULLISH", "BEARISH", "STRONG_BULL", "STRONG_BEAR"]:
            state_data = horizon_data[horizon_data["alpha_state"] == state]
            neutral_data = horizon_data[horizon_data["alpha_state"] == "NEUTRAL"]
            
            n_samples = len(state_data)
            
            # 샘플 수 확인
            if n_samples < ACCEPTANCE_CRITERIA["min_samples_hard_floor"]:
                result["warnings"].append(
                    f"horizon={horizon}, state={state}: "
                    f"샘플 수 {n_samples}개 — 평가 보류"
                )
                continue
            
            # IC 차이 확인
            if len(state_data) > 0 and len(neutral_data) > 0:
                delta_ic = abs(
                    state_data["ic"].mean() - neutral_data["ic"].mean()
                )
                t_stat = compute_t_stat(state_data["ic"], neutral_data["ic"])
                
                ic_pass = (
                    delta_ic > ACCEPTANCE_CRITERIA["min_delta_ic_vs_neutral"] or
                    t_stat > ACCEPTANCE_CRITERIA["min_t_stat"]
                )
                
                result["by_state"][f"h{horizon}_{state}"] = ic_pass
        
        # 해당 horizon 통과 여부
        horizon_states_passed = sum(
            1 for k, v in result["by_state"].items() 
            if k.startswith(f"h{horizon}_") and v
        )
        horizon_pass = horizon_states_passed >= 1
        result["by_horizon"][horizon] = horizon_pass
        
        if horizon_pass:
            horizons_passed += 1
    
    # 최종 판정
    result["passed"] = (
        horizons_passed >= ACCEPTANCE_CRITERIA["min_horizons_passing"]
    )
    
    if not result["passed"]:
        result["failures"].append(
            f"통과 horizon: {horizons_passed}개 "
            f"(최소 요구: {ACCEPTANCE_CRITERIA['min_horizons_passing']}개)"
        )
    
    return result
```

### 산출물
- [ ] `spec/acceptance_criteria.md` (수치 기준 고정 문서)
- [ ] `src/validation/acceptance_checker.py`
- [ ] `tests/test_acceptance.py`

---

## WP-4: Freeze / Versioning Policy

### 구현 목표
`src/pipeline/reproducibility.py` 구현

```python
# src/pipeline/reproducibility.py

import hashlib, json, uuid
from datetime import datetime

def generate_run_id() -> str:
    return str(uuid.uuid4())[:8]

def compute_config_hash(config: dict) -> str:
    config_str = json.dumps(config, sort_keys=True)
    return hashlib.sha256(config_str.encode()).hexdigest()[:16]

def create_run_metadata(
    config: dict,
    data_version: str,
    score_spec_version: str = "v1.0",
    feature_pack_version: str = "v1.0",
    phase: str = "phase_minus1"
) -> dict:
    """모든 실험에 첨부할 메타데이터 생성"""
    return {
        "run_id": generate_run_id(),
        "config_hash": compute_config_hash(config),
        "data_version": data_version,
        "score_spec_version": score_spec_version,
        "feature_pack_version": feature_pack_version,
        "phase": phase,
        "created_at": datetime.utcnow().isoformat(),
        "etf_available": config.get("etf_available", 0)
    }

def verify_reproducibility(
    run_id_1: str,
    run_id_2: str,
    artifacts_dir: str,
    tolerance: float = 1e-6
) -> dict:
    """
    두 run_id의 핵심 metric을 비교하여 재현성 검증.
    동일 config라면 결과가 tolerance 범위 내에서 동일해야 함.
    """
    ...
```

### 산출물
- [ ] `src/pipeline/reproducibility.py`
- [ ] `artifacts/runs/` 폴더 구조 생성

---

## WP-5: Validation QA

### Smoke Test 체크리스트

```python
# 실행 명령: python -m pytest tests/test_phase_minus1.py -v

def test_score_norm_etf_on():
    """ETF 가용 시: 최대 score=6, norm=1.0"""
    scores = calculate_alpha_score_norm(
        {"mvrv": 2, "exchange_reserve": 1, "etf_flow": 1, 
         "funding_rate": 1, "halving_phase": 1},
        etf_available=True
    )
    assert scores[0] == 1.0  # norm
    assert scores[1] == "STRONG_BULL"

def test_score_norm_etf_off():
    """ETF 미가용 시: ETF score=0, 분모는 여전히 6.0"""
    scores = calculate_alpha_score_norm(
        {"mvrv": 2, "exchange_reserve": 1, "etf_flow": 0,  # ETF=0
         "funding_rate": 1, "halving_phase": 1},
        etf_available=False
    )
    assert scores[0] == 5/6  # 5점 / 6점 분모
    assert scores[1] == "STRONG_BULL"

def test_pit_no_future_leakage():
    """PIT 필터 후 as_of_date 이후 데이터 없음"""
    ...

def test_acceptance_criteria_numeric():
    """정량 기준이 올바르게 적용되는지 확인"""
    ...
```

---

## ✅ Gate A 통과 조건 (체크리스트)

```
□ spec/data_availability_spec.md — 모든 alpha source에 availability_date 명시
□ src/data/point_in_time.py — 구현 완료 + unit test 통과
□ alpha_score_norm 6점 고정 분모 — 코드에 반영됨
□ etf_available meta-feature — panel에 저장됨
□ Pre-ETF / Post-ETF 분리 리포트 템플릿 — 생성됨
□ spec/acceptance_criteria.md — 정량 기준으로 재작성됨
□ src/pipeline/reproducibility.py — run_id, config_hash 발급 가능
□ tests/ — phase_minus1 관련 테스트 전체 pass
□ smoke test — spec vs 코드 일치 확인
```

**Gate A 실패 시**: Phase 0 성능 수치 해석 보류. spec과 코드 불일치 지점 먼저 수정.
