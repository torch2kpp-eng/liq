# PHASE_0.md — Live Stabilization

> **담당 서브에이전트**: B  
> **기간**: D6~D12  
> **선행 조건**: Gate A 통과 (Phase -1 완료)  
> **Gate**: Gate B 통과 후 Phase 1 진입 허용

---

## 🎯 이 Phase의 목적

> "끝까지 돈다 + 다시 돌려도 같다."

모델 성능 개선이 목표가 아님. **실행 안정성, artifact 생성, 재현성**이 전부다.

---

## 📋 Work Package 목록

| WP | 검증 축 | 우선순위 |
|----|---------|----------|
| WP-6 | Batch run — 4/8/13/26주 full run 성공 | P0 |
| WP-7 | Artifact — 경로/스키마/행 수 검증 | P0 |
| WP-8 | Schema — feature order, dtype, meta-feature | P0 |
| WP-9 | UI / TAB6 / TAB7 — 렌더 및 fallback | P1 |
| WP-10 | Cache / Reproducibility — 재실행 일관성 | P0 |
| WP-11 | Data Quality Gate — missing/stale/outlier | P1 |

---

## WP-6: Batch Run / Experiment Runner

### 구현 목표
`src/pipeline/runner.py` — 4/8/13/26주 horizon 병렬 실행

```python
# src/pipeline/runner.py

import logging
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)

HORIZONS = [4, 8, 13, 26]  # 고정값 — 변경 금지

class ExperimentRunner:
    """
    BTC Engine 실험 실행기.
    run_id 발급 → 데이터 로딩 → PIT 필터 → 모델 실행 → artifact 저장
    """
    
    def __init__(self, config: dict, artifacts_dir: str = "artifacts/runs"):
        self.config = config
        self.artifacts_dir = Path(artifacts_dir)
        self.metadata = create_run_metadata(config, ...)
        self.run_id = self.metadata["run_id"]
        
        # run별 artifacts 폴더 생성
        self.run_dir = self.artifacts_dir / self.run_id
        self.run_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Run initialized: run_id={self.run_id}")
    
    def run_all_horizons(self) -> dict:
        """
        4/8/13/26주 전 horizon 실행.
        개별 horizon 실패해도 나머지 계속 실행 (partial failure 허용).
        """
        results = {}
        
        for horizon in HORIZONS:
            try:
                logger.info(f"[run_id={self.run_id}] horizon={horizon}w 시작")
                result = self._run_single_horizon(horizon)
                results[horizon] = {"status": "success", "result": result}
                logger.info(f"[run_id={self.run_id}] horizon={horizon}w 완료")
                
            except Exception as e:
                # 실패해도 계속 진행, 에러 로그 보존
                logger.error(
                    f"[run_id={self.run_id}] horizon={horizon}w 실패: {e}",
                    exc_info=True
                )
                results[horizon] = {"status": "failed", "error": str(e)}
                self._save_error_artifact(horizon, e)
        
        self._save_summary(results)
        return results
    
    def _run_single_horizon(self, horizon: int) -> dict:
        """단일 horizon 실행"""
        # 1. 데이터 로딩 + PIT 필터
        # 2. Alpha score 계산
        # 3. 모델 실행 (ECM + Ridge + XGBoost)
        # 4. OOS predictions 저장
        # 5. Slice metrics 계산
        # 6. Artifact 저장
        ...
    
    def _save_error_artifact(self, horizon: int, error: Exception):
        """실패 실험도 반드시 보존"""
        error_path = self.run_dir / f"error_h{horizon}.json"
        error_data = {
            "run_id": self.run_id,
            "horizon": horizon,
            "error_type": type(error).__name__,
            "error_message": str(error),
            "timestamp": datetime.utcnow().isoformat()
        }
        with open(error_path, "w") as f:
            json.dump(error_data, f, indent=2)
    
    def _save_summary(self, results: dict):
        """실행 요약 저장"""
        summary = {
            **self.metadata,
            "horizons": {
                str(h): r["status"] for h, r in results.items()
            },
            "completed_at": datetime.utcnow().isoformat()
        }
        with open(self.run_dir / "summary.json", "w") as f:
            json.dump(summary, f, indent=2)
```

### 완료 조건
- [ ] 4/8/13/26주 전 horizon full run 1회 이상 오류 없이 완료
- [ ] partial failure 발생 시 어느 단계에서 실패했는지 로그 확인
- [ ] `artifacts/runs/{run_id}/summary.json` 생성 확인

---

## WP-7: Artifact 검증

### 필수 artifact 목록 및 스키마

```python
# src/pipeline/artifact_validator.py

REQUIRED_ARTIFACTS = {
    "summary.json": {
        "required_keys": ["run_id", "data_version", "score_spec_version", 
                          "config_hash", "horizons", "created_at"]
    },
    "oos_predictions.csv": {
        "required_columns": ["date", "horizon", "run_id", "config_hash",
                             "y_true", "y_pred", "alpha_state", "macro_regime",
                             "alpha_score_norm", "etf_available"],
        "min_rows": 10
    },
    "slice_metrics.csv": {
        "required_columns": ["horizon", "macro_regime", "alpha_state", 
                             "etf_available", "ic", "rank_ic", "sign_acc", 
                             "n_samples"],
        "min_rows": 1
    },
    "alpha_panel.csv": {
        "required_columns": ["date", "available_date", "mvrv_z", 
                             "reserve_pct_change", "etf_z", "funding_z",
                             "halving_phase", "alpha_score_norm", 
                             "alpha_state", "etf_available"],
        "min_rows": 50
    },
    "quality_gate.json": {
        "required_keys": ["missing_ratio", "stale_sources", 
                          "outlier_flags", "gate_passed"]
    }
}


def validate_artifacts(run_dir: str) -> dict:
    """
    run_dir 내 모든 artifact 존재 여부 및 스키마 검증.
    
    Returns:
        {"passed": bool, "missing": [str], "schema_errors": [str]}
    """
    result = {"passed": True, "missing": [], "schema_errors": []}
    run_path = Path(run_dir)
    
    for filename, spec in REQUIRED_ARTIFACTS.items():
        filepath = run_path / filename
        
        if not filepath.exists():
            result["missing"].append(filename)
            result["passed"] = False
            continue
        
        if filename.endswith(".csv"):
            df = pd.read_csv(filepath)
            missing_cols = set(spec["required_columns"]) - set(df.columns)
            if missing_cols:
                result["schema_errors"].append(
                    f"{filename}: 누락 컬럼 {missing_cols}"
                )
                result["passed"] = False
            
            if len(df) < spec.get("min_rows", 0):
                result["schema_errors"].append(
                    f"{filename}: 행 수 {len(df)} < 최소 {spec['min_rows']}"
                )
                result["passed"] = False
    
    return result
```

### 완료 조건
- [ ] 모든 필수 artifact 생성 확인
- [ ] schema mismatch 0건
- [ ] 행 수 최소 기준 충족

---

## WP-8: Schema 안정화

```python
# src/data/feature_store.py

class FeatureStore:
    """
    Feature matrix 스키마 관리.
    fit과 predict에서 동일한 feature order 보장.
    """
    
    def __init__(self, schema_version: str = "v1.0"):
        self.schema_version = schema_version
        self._feature_order: list[str] | None = None
    
    def fit_schema(self, df: pd.DataFrame) -> "FeatureStore":
        """훈련 시 feature order 고정"""
        self._feature_order = list(df.columns)
        return self
    
    def apply_schema(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        예측 시 훈련과 동일한 feature order 강제 적용.
        누락 컬럼은 0으로 채움, 추가 컬럼은 제거.
        """
        if self._feature_order is None:
            raise ValueError("fit_schema()를 먼저 실행하세요")
        
        # 누락 컬럼 0으로 채움
        for col in self._feature_order:
            if col not in df.columns:
                df[col] = 0.0
                logger.warning(f"누락 컬럼 {col}을 0으로 채움")
        
        return df[self._feature_order]
    
    def validate_schema(self, df: pd.DataFrame) -> dict:
        """스키마 일치 여부 검증"""
        if self._feature_order is None:
            return {"valid": False, "reason": "schema not fitted"}
        
        current = set(df.columns)
        expected = set(self._feature_order)
        
        return {
            "valid": current == expected,
            "missing": list(expected - current),
            "extra": list(current - expected),
            "schema_version": self.schema_version
        }
    
    def check_meta_features(self, df: pd.DataFrame) -> dict:
        """etf_available, score_spec_version 등 메타 컬럼 존재 확인"""
        required_meta = ["etf_available"]
        missing = [c for c in required_meta if c not in df.columns]
        return {"valid": len(missing) == 0, "missing_meta": missing}
```

### 완료 조건
- [ ] one-hot 이후 feature order가 fit/predict에서 동일
- [ ] etf_available meta-feature 누락 없음
- [ ] schema_report.csv 생성

---

## WP-9: UI / Fallback / Graceful Degradation

### TAB6 Alpha Integration Lab 요구사항

```python
# src/ui/tab6_alpha.py

def render_tab6(alpha_panel: pd.DataFrame | None, 
                forward_metrics: pd.DataFrame | None):
    """
    Alpha Integration Lab UI.
    데이터 없어도 빈 화면 대신 상태 메시지 출력.
    """
    if alpha_panel is None:
        st.warning("⚠️ Alpha panel 데이터 없음. 데이터를 먼저 로딩하세요.")
        st.info("실행 명령: python -m src.pipeline.runner --phase 0")
        return
    
    # 정상 렌더링
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("현재 Alpha State")
        render_alpha_state_gauge(alpha_panel)
    
    with col2:
        st.subheader("Component Score 분해")
        render_component_breakdown(alpha_panel)
    
    # ETF 미가용 구간 명시
    if alpha_panel["etf_available"].iloc[-1] == 0:
        st.info("ℹ️ 현재 ETF 데이터 미가용 구간. Score는 5-component 기준 (분모 6점 고정).")
    
    # Pre/Post ETF 분리 표시
    render_pre_post_etf_split(alpha_panel)
```

### TAB7 Experiment Viewer 요구사항

```python
# src/ui/tab7_experiment.py

def render_tab7(experiment_dir: str):
    """
    실험 결과 viewer.
    artifact 없어도 안내 문구와 실행 명령 제시.
    """
    run_dirs = list(Path(experiment_dir).glob("*/"))
    
    if not run_dirs:
        st.warning("⚠️ 실험 artifact가 없습니다.")
        st.code("python -m src.pipeline.runner --horizon all", language="bash")
        return
    
    # run_id 선택
    selected_run = st.selectbox(
        "Run ID 선택",
        options=[d.name for d in run_dirs],
        index=0
    )
    
    # artifact 로딩 및 표시
    render_run_results(experiment_dir, selected_run)
```

### Partial Data Fallback 테스트

```python
# 필수 smoke test
def test_tab6_no_data():
    """데이터 없을 때 빈 화면이 아닌 안내 메시지 출력"""
    render_tab6(alpha_panel=None, forward_metrics=None)
    # 에러 발생하지 않고 안내 메시지 출력 확인

def test_tab6_no_etf():
    """ETF 미가용 구간에서도 alpha panel 정상 생성"""
    panel_without_etf = create_test_panel(etf_available=False)
    render_tab6(alpha_panel=panel_without_etf, forward_metrics=None)
    # score 체계 붕괴 없이 정상 렌더링 확인
```

---

## WP-10: Cache / Reproducibility

```python
# src/pipeline/cache.py

class CacheManager:
    """
    Feature matrix 및 model artifact 캐시 관리.
    data_version + config_hash 기반 cache key.
    """
    
    CACHE_TTL_DAYS = 7  # 7일 이상 된 캐시 자동 경고
    
    def __init__(self, cache_dir: str = ".cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
    
    def get_cache_key(self, data_version: str, config_hash: str) -> str:
        return f"{data_version}_{config_hash}"
    
    def get(self, key: str) -> pd.DataFrame | None:
        """캐시 hit 시 반환, miss 시 None"""
        cache_file = self.cache_dir / f"{key}.parquet"
        
        if not cache_file.exists():
            return None
        
        # freshness 확인
        age_days = (datetime.now() - 
                   datetime.fromtimestamp(cache_file.stat().st_mtime)).days
        
        if age_days > self.CACHE_TTL_DAYS:
            logger.warning(f"캐시 {key}가 {age_days}일 경과 — 갱신 권장")
        
        return pd.read_parquet(cache_file)
    
    def set(self, key: str, data: pd.DataFrame) -> None:
        """캐시 저장"""
        cache_file = self.cache_dir / f"{key}.parquet"
        data.to_parquet(cache_file)
        logger.info(f"캐시 저장: {key}")
    
    def invalidate(self, key: str) -> None:
        """캐시 무효화"""
        cache_file = self.cache_dir / f"{key}.parquet"
        if cache_file.exists():
            cache_file.unlink()
            logger.info(f"캐시 무효화: {key}")
```

### 재현성 검증 자동화

```python
def run_reproducibility_check(
    config: dict,
    artifacts_dir: str,
    tolerance: float = 1e-6
) -> dict:
    """
    동일 config를 2회 실행하여 핵심 metric 일치 확인.
    Phase 0 완료 조건 중 하나.
    """
    run1 = ExperimentRunner(config, artifacts_dir).run_all_horizons()
    run2 = ExperimentRunner(config, artifacts_dir).run_all_horizons()
    
    # scorecard 비교
    for horizon in HORIZONS:
        score1 = load_scorecard(run1[horizon]["run_id"], horizon)
        score2 = load_scorecard(run2[horizon]["run_id"], horizon)
        
        diff = abs(score1["ic"].mean() - score2["ic"].mean())
        assert diff < tolerance, \
            f"재현성 실패: horizon={horizon}, IC 차이={diff:.6f}"
    
    return {"passed": True, "runs": [run1, run2]}
```

---

## WP-11: Data Quality Gate

```python
# src/data/quality_gate.py

class DataQualityGate:
    """
    데이터 품질 이상 사전 탐지 및 차단.
    live mode에서는 차단 규칙과 경고 규칙 분리.
    """
    
    THRESHOLDS = {
        "max_missing_ratio": 0.10,      # 10% 이상 결측 → 차단
        "max_stale_days": 14,           # 14일 이상 stale → 차단
        "outlier_z_threshold": 5.0,     # z > 5 → 경고
        "min_weekly_rows": 50           # 최소 행 수
    }
    
    def check(self, 
              panel: pd.DataFrame,
              as_of_date: pd.Timestamp,
              mode: str = "live") -> dict:
        """
        Args:
            mode: "live" (차단 포함) | "research" (경고만)
        
        Returns:
            {
                "gate_passed": bool,
                "blocking_issues": [str],   # 차단 사유
                "warnings": [str],          # 경고 (계속 진행 가능)
                "missing_ratio": float,
                "stale_sources": [str]
            }
        """
        result = {
            "gate_passed": True,
            "blocking_issues": [],
            "warnings": [],
            "missing_ratio": 0.0,
            "stale_sources": []
        }
        
        # 결측률 확인
        missing_ratio = panel.isnull().mean().mean()
        result["missing_ratio"] = missing_ratio
        
        if missing_ratio > self.THRESHOLDS["max_missing_ratio"]:
            issue = f"결측률 {missing_ratio:.1%} > {self.THRESHOLDS['max_missing_ratio']:.1%}"
            if mode == "live":
                result["blocking_issues"].append(issue)
                result["gate_passed"] = False
            else:
                result["warnings"].append(issue)
        
        # stale data 확인 (주간 cut-off 미완성 데이터)
        for source, rule in PIT_RULES.items():
            latest_date = panel["date"].max()
            expected_date = as_of_date - pd.Timedelta(days=rule["lag_days"])
            
            if latest_date < expected_date - pd.Timedelta(days=self.THRESHOLDS["max_stale_days"]):
                result["stale_sources"].append(source)
                if mode == "live":
                    result["gate_passed"] = False
        
        # 주간 cut-off 전 집계 미완성 처리
        # 미완성 데이터 → neutral 처리 (차단이 아님)
        
        return result
```

---

## ✅ Gate B 통과 조건 (체크리스트)

```
□ WP-6: 4/8/13/26주 batch run 1회 이상 오류 없이 완주
□ WP-7: 모든 필수 artifact 생성 + schema mismatch 0건
□ WP-8: feature schema — fit/predict 동일, etf_available 포함
□ WP-9: TAB6/TAB7 정상 렌더 + source-missing fallback 테스트 완료
□ WP-10: 동일 config rerun 시 핵심 metric 일관성 확인
□ WP-11: quality gate 경고/차단 규칙 정상 동작

모든 체크 완료 시 → Gate B 통과 → Phase 1 진입 허용
```

**Gate B 실패 시**: Phase 1 실험 보류. runtime/cache/path 정렬 문제 먼저 해결.
