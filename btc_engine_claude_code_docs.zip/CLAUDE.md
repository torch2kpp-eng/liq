# CLAUDE.md — BTC Macro Prediction Engine
## Master Orchestration Document

> **Version**: v2.20 Revised  
> **Last Updated**: 2026-03-21  
> **Status**: Active Development  
> **Scope**: Phase -1 through Phase 6 (Full Implementation)

---

## 🧭 이 문서의 역할

이 문서는 **Claude Code 오케스트레이터**의 최상위 지침서다.  
Claude Code는 이 문서를 읽고, 하위 Phase 문서들을 서브에이전트에게 위임하여 전체 엔진을 구현한다.

**멀티에이전트 위임 구조:**
```
CLAUDE.md (오케스트레이터)
├── docs/PHASE_MINUS1.md  → 서브에이전트 A: Validation Guardrails
├── docs/PHASE_0.md       → 서브에이전트 B: Live Stabilization
├── docs/PHASE_1.md       → 서브에이전트 C: Structural Validation
├── docs/PHASE_2.md       → 서브에이전트 D: Signal Expansion
├── docs/PHASE_3.md       → 서브에이전트 E: Interaction-first ML
├── docs/PHASE_4.md       → 서브에이전트 F: Position Translation
├── docs/PHASE_5.md       → 서브에이전트 G: Reliability & Observability
└── docs/PHASE_6.md       → 서브에이전트 H: Champion Governance
```

---

## 🎯 프로젝트 핵심 목적

**BTC 주간 수익률을 4/8/13/26주 horizon으로 예측하고, 이를 실제 포지션 사이징으로 연결하는 운영형 예측 엔진.**

### 설계 철학 (절대 원칙 — 모든 서브에이전트가 준수)

| 원칙 | 실무 해석 |
|------|-----------|
| **Walk-forward is the truth** | 모든 개선 판단은 expanding-window walk-forward OOS로만 |
| **Validation before complexity** | 구조 검증 없이 LightGBM/HMM/딥러닝으로 진입 금지 |
| **Interaction-first ML** | 복잡한 모델보다 조건부 정보 분리가 먼저 |
| **Calibration over prediction inflation** | 알파는 base forecast 대체가 아닌 confidence 보정 레이어 |
| **Production means reproducibility** | 동일 config 재실행 시 동일 결과 — 이것이 운영의 기본 |
| **Point-in-Time integrity** | 예측 시점에 "알 수 있었던 데이터"만 사용 |

---

## 🏗️ 전체 엔진 아키텍처

### 레이어 구조

```
┌─────────────────────────────────────────────────────┐
│                   OUTPUT LAYER                       │
│  Forward Path / Fan Chart / Position Signal / UI     │
├─────────────────────────────────────────────────────┤
│               STRATEGY LAYER (Phase 4)               │
│  Position Sizing / Path Calibration / Risk Overlay   │
├─────────────────────────────────────────────────────┤
│              ALPHA LAYER (v2.19, Phase 1)            │
│  MVRV / Reserve / ETF / Funding / Halving → State    │
├─────────────────────────────────────────────────────┤
│              MODEL LAYER (Phase 3)                   │
│  ECM (Champion) / Ridge / LightGBM / Stacking        │
├─────────────────────────────────────────────────────┤
│              SIGNAL LAYER (Phase 2)                  │
│  Global M2 / Derivatives / OHLC / On-chain           │
├─────────────────────────────────────────────────────┤
│           DATA & VALIDATION LAYER (Phase -1/0)       │
│  Point-in-Time / Score Norm / Acceptance Criteria    │
└─────────────────────────────────────────────────────┘
```

### 현재 모델 역할 (변경 금지)

| 모델 | 역할 | 비고 |
|------|------|------|
| **ECM** | 챔피언 기본 모델 | 4/8/13/26주 전 구간 우세 |
| **Ridge** | 고속 보조 모델 | 단기 민첩성, 운영 효율 |
| **XGBoost** | 실험용 후보 | 4주 제한 피처 환경만 |
| **LightGBM** | Phase 3에서 추가 | Ensemble diversity 목적 |

---

## 📁 권장 프로젝트 폴더 구조

```
btc_engine/
├── CLAUDE.md                          # 이 문서
├── docs/                              # Phase별 구현 문서
│   ├── PHASE_MINUS1.md
│   ├── PHASE_0.md
│   ├── PHASE_1.md
│   ├── PHASE_2.md
│   ├── PHASE_3.md
│   ├── PHASE_4.md
│   ├── PHASE_5.md
│   └── PHASE_6.md
├── spec/                              # Phase -1 산출물 (고정값)
│   ├── data_availability_spec.md
│   ├── scoring_spec.md
│   └── acceptance_criteria.md
├── src/
│   ├── data/
│   │   ├── loader.py                  # 데이터 로딩 (PIT 규칙 적용)
│   │   ├── point_in_time.py           # PIT 필터 핵심 모듈
│   │   ├── quality_gate.py            # 데이터 품질 게이트
│   │   └── feature_store.py           # Feature 저장 및 버전 관리
│   ├── alpha/
│   │   ├── scoring.py                 # Alpha score 계산 (6점 고정 분모)
│   │   ├── state_mapper.py            # Score → State 변환
│   │   └── lead_lag.py                # ETF lead-lag 검증
│   ├── models/
│   │   ├── ecm.py                     # ECM 챔피언 모델
│   │   ├── ridge.py                   # Ridge 보조 모델
│   │   ├── xgboost_model.py           # XGBoost 실험 모델
│   │   ├── lightgbm_model.py          # Phase 3 추가
│   │   └── ensemble.py                # 앙상블 레이어
│   ├── validation/
│   │   ├── walk_forward.py            # Walk-forward OOS
│   │   ├── conditional_metrics.py     # State-conditioned IC 등
│   │   └── acceptance_checker.py      # 정량 기준 자동 판정
│   ├── strategy/
│   │   ├── position_sizing.py         # Phase 4 포지션 규칙
│   │   ├── path_calibration.py        # Path multiplier
│   │   └── risk_overlay.py            # Beta cap, stop logic
│   ├── pipeline/
│   │   ├── runner.py                  # 실험 runner (run_id 발급)
│   │   ├── cache.py                   # Cache 관리
│   │   └── reproducibility.py        # Config hash, freeze
│   └── ui/
│       ├── tab6_alpha.py              # Alpha Integration Lab
│       ├── tab7_experiment.py         # Experiment Viewer
│       └── dashboard.py              # 운영형 대시보드
├── artifacts/
│   └── runs/
│       └── {run_id}/
│           ├── summary.json
│           ├── schema_report.csv
│           ├── scorecard.csv
│           └── quality_gate.json
├── logs/
│   ├── runtime.log
│   ├── cache.log
│   └── rerun_consistency.log
└── tests/
    ├── test_point_in_time.py
    ├── test_scoring.py
    └── test_acceptance.py
```

---

## 🚦 Phase Gate 시스템 (오케스트레이터 핵심 규칙)

```
Phase -1 ──[Gate A]──► Phase 0 ──[Gate B]──► Phase 1 ──[Gate C]──►
Phase 2 ──[G2-In]──► Phase 3 ──[G3-In]──► Phase 4 ──[G4-In]──►
Phase 5 ──[G5-In]──► Phase 6
```

**Gate 실패 시 행동 원칙:**
- 다음 Phase로 절대 진입하지 않는다
- 실패 원인을 `phase_decision_card.md`에 기록한다
- 실패한 실험도 `error_log.txt`에 보존한다 (삭제 금지)

| Gate | 통과 조건 요약 |
|------|----------------|
| **Gate A** | Data Availability Spec + score_norm 6점 고정 + acceptance criteria 수치화 완료 |
| **Gate B** | Full run 성공 + artifact 생성 + schema mismatch 0건 + rerun 일관성 확인 |
| **Gate C** | State separation + position risk reduction + ETF gating 판단 완료 |
| **G2-In** | Phase 1 종료 판정 + horizon별 alpha pack 초안 확보 |
| **G3-In** | 승격 후보 신호팩 1개 이상 + invalid signal 제거 완료 |
| **G4-In** | 조건부 lift 또는 calibration lift 재현 확인 |
| **G5-In** | 전략 규칙 초안 + live artifact 구조 확정 |
| **G6-In** | 운영형 run-card + 모드 분리 기준 초안 확보 |

---

## 📊 Alpha Score 설계 (v2.19 기준 — 고정)

### Component Scoring 규칙

| 지표 | 조건 | 점수 |
|------|------|------|
| MVRV z-score | ≤ 0.0 / ≤ 0.5 / ≥ 5.0 / ≥ 7.0 | +2 / +1 / -1 / -2 |
| Exchange Reserve (4주 변화율) | ≤ -3% / ≥ +3% | +1 / -1 |
| ETF Net Flow (4주 z-score) | ≥ 0.5 / ≤ -0.5 | +1 / -1 |
| Funding Rate (8주 평균 z) | ≤ -1.5 / ≥ +1.5 | +1 / -1 |
| Halving Phase | post_mid / bear_phase | +1 / -1 |

### Score Normalization (절대 변경 금지)

```python
# 항상 ETF 포함 기준 6점 고정 분모
alpha_score_norm = raw_score / 6.0

# ETF 미가용 구간: ETF score = 0, etf_available = 0
# ETF 가용 구간: etf_available = 1
```

### State Map

| score_norm | State |
|------------|-------|
| ≥ 0.55 | STRONG_BULL |
| 0.20 ~ 0.55 | BULLISH |
| -0.20 ~ 0.20 | NEUTRAL |
| -0.55 ~ -0.20 | BEARISH |
| ≤ -0.55 | STRONG_BEAR |

### Position Multiplier (State별 고정값)

| State | Position Multiplier |
|-------|---------------------|
| STRONG_BEAR | 0.25 |
| BEARISH | 0.55 |
| NEUTRAL | 0.85 |
| BULLISH | 1.00 |
| STRONG_BULL | 1.10 |

---

## 📋 공통 Acceptance Criteria (모든 Phase에서 준수)

```python
ACCEPTANCE_CRITERIA = {
    "min_oos_samples_per_state": 15,      # 15개 미만 state는 평가 보류
    "min_samples_hard_floor": 10,          # 10개 미만은 판정 불가
    "min_delta_ic": 0.05,                  # NEUTRAL 대비 |ΔIC| > 0.05
    "min_t_stat": 1.5,                     # 또는 t-stat > 1.5
    "min_sign_accuracy_lift": 0.05,        # 50% 대비 +5%p 이상
    "min_horizons_passing": 2,             # 4개 horizon 중 최소 2개
    "max_non_target_ic_degradation": -0.01 # 비타깃 horizon IC 악화 한도
}
```

---

## 🗂️ 공통 Artifact 스키마 (모든 실험에서 필수)

### 모든 artifact에 반드시 포함할 메타 필드

```python
REQUIRED_META_FIELDS = [
    "run_id",              # UUID
    "data_version",        # 데이터 스냅샷 버전
    "score_spec_version",  # scoring 규격 버전
    "feature_pack_version",
    "config_hash",         # SHA256 of config
    "created_at",          # ISO timestamp
    "phase",               # "phase_minus1" | "phase_0" | ...
    "etf_available",       # 0 or 1
    "horizon",             # 4 | 8 | 13 | 26
]
```

### 핵심 Panel 파일

| 파일 | 필수 컬럼 |
|------|-----------|
| `weekly_panel.parquet` | date, available_date, data_version, [features] |
| `alpha_panel.parquet` | date, available_date, mvrv, reserve, etf_flow, funding, halving, alpha_score_norm, alpha_state, etf_available |
| `oos_predictions.csv` | date, horizon, run_id, config_hash, y_true, y_pred, alpha_state, macro_regime |
| `slice_metrics.csv` | horizon, macro_regime, alpha_state, etf_available, ic, rank_ic, sign_acc, n_samples |

---

## 🔧 Point-in-Time 규칙 요약 (Phase -1에서 확정, 전 Phase 준수)

| 데이터 소스 | 사용 허용 기준 | 이유 |
|-------------|----------------|------|
| MVRV | T-7일까지 | 주간 집계 확정 지연 + 소급 수정 마진 |
| Exchange Reserve | T-7일까지 | 동일 |
| ETF Net Flow | T-2일까지 | T+1 발표 + 1일 안전 마진 |
| Funding Rate | 실시간 가용 | 지연 없음 |
| Halving Phase | 실시간 가용 | 내장 날짜 로직 |

```python
# point_in_time.py 핵심 함수 시그니처
def point_in_time_filter(
    df: pd.DataFrame,
    as_of_date: pd.Timestamp,
    source: str  # "mvrv" | "reserve" | "etf" | "funding" | "halving"
) -> pd.DataFrame:
    """예측 시점 기준으로 실제 가용한 데이터만 반환"""
    ...
```

---

## 🤖 오케스트레이터 실행 지침

### Claude Code 오케스트레이터가 해야 할 일

1. **현재 repo 구조 파악**: 기존 코드에서 ECM, Ridge, XGBoost, TAB6/TAB7 구현 현황 확인
2. **갭 분석**: 이 문서의 폴더 구조 대비 missing 파일/모듈 식별
3. **Phase 순서 준수**: 반드시 Phase -1 → 0 → 1 → ... 순서로 진행. Gate 미통과 시 중단
4. **서브에이전트 위임**: 각 Phase 문서를 서브에이전트에게 전달하여 구현
5. **실패 보존**: 실패한 실험/코드도 `error_log.txt`에 보존 후 계속 진행

### 서브에이전트 위임 시 전달할 컨텍스트

```
각 서브에이전트에게 반드시 전달:
1. 이 CLAUDE.md 전체
2. 해당 Phase의 docs/PHASE_X.md
3. 기존 repo의 관련 파일 목록
4. 이전 Phase의 산출물 (Gate 통과 여부 포함)
```

### 코드 품질 기준

- **모든 함수**: docstring + type hint 필수
- **모든 실험**: run_id 발급 + artifact 저장 필수
- **테스트**: 핵심 모듈(point_in_time, scoring, acceptance)은 unit test 필수
- **로그**: 모든 실험 실행에 structured logging (JSON 형식)

---

## ⚠️ 절대 하지 말아야 할 것 (Anti-patterns)

```
❌ Phase Gate 미통과 상태에서 다음 Phase 코드 작성
❌ score_norm 분모를 ETF 6점 고정이 아닌 가변 분모로 구현
❌ Point-in-Time 필터 없이 백테스트 실행
❌ Look-ahead bias 가능성 있는 데이터를 검증 없이 사용
❌ "차별화 관찰됨" 같은 정성 판정으로 Phase 승격
❌ path multiplier를 전체 샘플 평균으로만 평가 (base 방향 분리 필수)
❌ ETF를 lead-lag 검증 없이 예측 feature로 사용
❌ 실패한 실험 artifact 삭제
❌ score 정의 변경과 threshold 튜닝을 동시에 수행
❌ in-sample 최적화로 threshold 설정
```

---

## 📅 권장 전체 타임라인

| 기간 | Phase | 핵심 산출물 |
|------|-------|-------------|
| D1~D5 | Phase -1 | Data Availability Spec, scoring patch, acceptance criteria |
| D6~D12 | Phase 0 | Full run 성공, artifact manifest, rerun consistency |
| W3~W4 | Phase 1 | Conditional metrics, DD 비교표, ETF gate report |
| W5~W8 | Phase 2 | 신호팩 승격표, invalid signal 목록 |
| W9~W12 | Phase 3 | Interaction 후보, LightGBM 판정, calibration spec |
| W13~W14 | Phase 4 | Position policy scorecard, 비용 반영 전략 카드 |
| W15~W16 | Phase 5 | Runtime profile, data gate, UI spec |
| W17~W18 | Phase 6 | Champion registry, rollback playbook |

---

*이 문서는 모든 서브에이전트의 최상위 권한 문서입니다. 충돌 시 이 문서의 원칙이 우선합니다.*
